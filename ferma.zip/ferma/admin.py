"""Админ-панель и сайт модерации (/admin): очередь объявлений, роли, блокировки, платежи, справочники, рассылка."""
import csv
import io
from datetime import date, datetime, timedelta

from flask import (Blueprint, Response, abort, flash, g, redirect, render_template, request,
                   url_for)

import logic
from auth import role_required
from db import fmt, get_db, now, now_s, q_all, q_one, q_val, tx

bp = Blueprint("admin", __name__, url_prefix="/admin")
PER_PAGE = 20          # по ТЗ: таблица на модерацию с пагинацией по 20


@bp.before_request
@role_required(logic.ROLE_ADMIN)
def _only_admin():
    return None


def log(conn, action, ad_id=None, user_id=None, details=None):
    """Журнал действий администраторов/модераторов (требование ТЗ)."""
    conn.execute("INSERT INTO moderation_log(moderator_id, action, ad_id, user_id, details, created_at) VALUES (?,?,?,?,?,?)",
                 (g.user["id"], action, ad_id, user_id, details, now_s()))


# ----------------------------------------------------------------------------
# Обзор и статистика
# ----------------------------------------------------------------------------
@bp.route("/")
def dashboard():
    since = fmt(now() - timedelta(days=30))
    stats = dict(
        users=q_val("SELECT COUNT(*) FROM users"),
        sellers=q_val("SELECT COUNT(*) FROM users WHERE roles & 2 > 0"),
        buyers=q_val("SELECT COUNT(*) FROM users WHERE roles & 1 > 0"),
        active=q_val("SELECT COUNT(*) FROM ads WHERE status = 'active'"),
        queue=q_val("SELECT COUNT(*) FROM ads WHERE status = 'moderation'"),
        awaiting=q_val("SELECT COUNT(*) FROM ads WHERE status = 'awaiting_payment'"),
        income30=q_val("SELECT SUM(amount) FROM payments WHERE status = 'paid' AND paid_at >= ?", (since,)),
        income_all=q_val("SELECT SUM(amount) FROM payments WHERE status = 'paid'"),
        complaints=q_val("SELECT COUNT(*) FROM complaints WHERE status = 'new'"),
        reserves=q_val("SELECT COUNT(*) FROM reservations WHERE status IN ('requested','confirmed')"),
    )
    days = [(date.today() - timedelta(days=i)).isoformat() for i in range(13, -1, -1)]
    pay = {r["d"]: r for r in q_all("SELECT substr(paid_at, 1, 10) AS d, COUNT(*) AS n, SUM(amount) AS s FROM payments "
                                   "WHERE status = 'paid' AND paid_at >= ? GROUP BY d", (days[0],))}
    new_ads = {r["d"]: r["n"] for r in q_all("SELECT substr(created_at, 1, 10) AS d, COUNT(*) AS n FROM ads "
                                             "WHERE created_at >= ? GROUP BY d", (days[0],))}
    series = [dict(day=d, pay=(pay[d]["s"] if d in pay else 0), ads=new_ads.get(d, 0)) for d in days]
    # СВЯЗИ: categories 1—N ads (category_id): объявления по категориям (график).
    by_cat = q_all("SELECT c.name AS name, COUNT(a.id) AS n FROM categories AS c LEFT JOIN ads AS a "
                   "ON a.category_id = c.id AND a.status = 'active' GROUP BY c.id, c.name ORDER BY n DESC, c.sort_order")
    return render_template("admin/dashboard.html", stats=stats, series=series, by_cat=by_cat,
                           max_pay=max([s["pay"] for s in series] + [1]), max_ads=max([s["ads"] for s in series] + [1]),
                           max_cat=max([r["n"] for r in by_cat] + [1]))


# ----------------------------------------------------------------------------
# Модерация объявлений
# ----------------------------------------------------------------------------
@bp.route("/moderation")
def moderation():
    cat = request.args.get("category", type=int)
    seller = request.args.get("seller", "").strip()
    order = "a.created_at DESC" if request.args.get("sort") == "new" else "a.created_at ASC"
    where, params = ["a.status = 'moderation'"], []
    if cat:
        where.append("a.category_id = ?")
        params.append(cat)
    if seller:
        where.append("(u.name LIKE ? OR CAST(u.id AS TEXT) = ?)")
        params += [f"%{seller}%", seller]
    clause = " WHERE " + " AND ".join(where)
    # СВЯЗИ: ads N—1 users (seller_id) и N—1 categories (category_id): очередь с продавцом и категорией.
    base = "FROM (ads AS a INNER JOIN users AS u ON u.id = a.seller_id) INNER JOIN categories AS c ON c.id = a.category_id"
    total = q_val("SELECT COUNT(*) " + base + clause, params)
    page, pages, off = logic.paginate(total, request.args.get("page", 1, type=int), PER_PAGE)
    rows = q_all("SELECT a.id AS id, a.title AS title, a.price AS price, a.unit AS unit, a.created_at AS created_at, "
                 "u.name AS seller_name, u.id AS seller_id, c.name AS category_name, "
                 "(SELECT file_path FROM ad_photos WHERE ad_id = a.id ORDER BY position LIMIT 1) AS photo, "
                 "(SELECT COUNT(*) FROM ad_photos WHERE ad_id = a.id) AS photos "
                 + base + clause + f" ORDER BY {order} LIMIT {PER_PAGE} OFFSET {off}", params)
    return render_template("admin/moderation.html", rows=rows, page=page, pages=pages, total=total, cat=cat, seller=seller,
                           sort=request.args.get("sort", ""), cats=q_all("SELECT * FROM categories ORDER BY sort_order"))


@bp.route("/moderation/<int:ad_id>")
def review(ad_id):
    # СВЯЗИ: ads N—1 users (seller_id), N—1 categories (category_id).
    ad = q_one("SELECT a.*, u.name AS seller_name, u.farm_name AS farm_name, u.phone_masked AS phone_masked, "
               "u.created_at AS seller_since, u.phone_confirmed AS phone_confirmed, c.name AS category_name "
               "FROM (ads AS a INNER JOIN users AS u ON u.id = a.seller_id) INNER JOIN categories AS c ON c.id = a.category_id "
               "WHERE a.id = ?", (ad_id,))
    if ad is None:
        abort(404)
    photos = q_all("SELECT file_path FROM ad_photos WHERE ad_id = ? ORDER BY position", (ad_id,))
    hist = q_all("SELECT status, COUNT(*) AS n FROM ads WHERE seller_id = ? GROUP BY status", (ad["seller_id"],))
    nxt = q_val("SELECT id FROM ads WHERE status = 'moderation' AND id <> ? ORDER BY created_at LIMIT 1", (ad_id,), None)
    return render_template("admin/review.html", ad=ad, photos=photos, hist=hist, locs=logic.ad_locations_text(ad_id),
                           nxt=nxt, presets=logic.PRESET_REASONS)


@bp.route("/moderation/<int:ad_id>/<action>", methods=["POST"])
def review_action(ad_id, action):
    conn = get_db()
    with tx(conn):
        ad = conn.execute("SELECT * FROM ads WHERE id = ?", (ad_id,)).fetchone()
        if ad is None:
            abort(404)
        if ad["status"] != "moderation":
            flash("Это объявление уже обработано.", "error")
            return redirect(url_for("admin.moderation"))
        link = f"/seller/ads/{ad_id}"
        if action == "approve":
            conn.execute("UPDATE ads SET status = 'awaiting_payment', approved_at = ?, moderator_id = ?, was_approved = 1, "
                         "reject_reason = NULL WHERE id = ?", (now_s(), g.user["id"], ad_id))
            if logic.PAID_MODE:
                logic.notify(conn, ad["seller_id"], f"Объявление «{ad['title']}» одобрено. Оплатите размещение "
                             f"({logic.AD_PRICE_RUB} ₽ на 24 часа), чтобы оно появилось в каталоге.", link)
            else:
                logic.notify(conn, ad["seller_id"], f"Объявление «{ad['title']}» одобрено. Размещение бесплатное в первый год — "
                             "нажмите «Опубликовать» в карточке объявления.", link)
            log(conn, "approve", ad_id, ad["seller_id"])
            flash(f"Объявление №{ad_id} одобрено.", "success")
        elif action in ("reject", "block"):
            reason = request.form.get("reason", "").strip() or request.form.get("preset", "").strip()
            if len(reason) < 3:
                flash("Укажите причину отклонения.", "error")
                return redirect(url_for("admin.review", ad_id=ad_id))
            conn.execute("UPDATE ads SET status = 'rejected', reject_reason = ?, moderator_id = ? WHERE id = ?",
                         (reason, g.user["id"], ad_id))
            logic.notify(conn, ad["seller_id"], f"Объявление «{ad['title']}» отклонено: {reason}", link)
            log(conn, "reject", ad_id, ad["seller_id"], reason)
            if action == "block":
                days = request.form.get("days", "7")
                if days == "forever":
                    conn.execute("UPDATE users SET blocked_forever = 1 WHERE id = ?", (ad["seller_id"],))
                    until = "навсегда"
                else:
                    d = int(days) if days.isdigit() and 0 < int(days) <= 365 else 7
                    conn.execute("UPDATE users SET blocked_until = ? WHERE id = ?", (fmt(now() + timedelta(days=d)), ad["seller_id"]))
                    until = f"на {d} дн."
                logic.notify(conn, ad["seller_id"], f"Ваш аккаунт продавца заблокирован {until}. Причина: {reason}")
                log(conn, "block_seller", ad_id, ad["seller_id"], f"{until}: {reason}")
                flash(f"Объявление отклонено, продавец заблокирован {until}.", "success")
            else:
                flash(f"Объявление №{ad_id} отклонено, причина отправлена продавцу.", "success")
        else:
            abort(404)
    nxt = q_val("SELECT id FROM ads WHERE status = 'moderation' ORDER BY created_at LIMIT 1", (), None)
    return redirect(url_for("admin.review", ad_id=nxt) if nxt and request.form.get("next") else url_for("admin.moderation"))


# ----------------------------------------------------------------------------
# Пользователи, роли, блокировки
# ----------------------------------------------------------------------------
@bp.route("/users")
def users():
    q = request.args.get("q", "").strip()
    role = request.args.get("role", "")
    where, params = [], []
    if q:
        where.append("(name LIKE ? OR phone_masked LIKE ? OR CAST(id AS TEXT) = ?)")
        params += [f"%{q}%", f"%{q}%", q]
    if role in ("1", "2", "4"):
        where.append("roles & ? > 0")
        params.append(int(role))
    clause = (" WHERE " + " AND ".join(where)) if where else ""
    total = q_val("SELECT COUNT(*) FROM users" + clause, params)
    page, pages, off = logic.paginate(total, request.args.get("page", 1, type=int), PER_PAGE)
    # СВЯЗИ: users 1—N ads (seller_id): число объявлений продавца.
    rows = q_all("SELECT u.*, (SELECT COUNT(*) FROM ads WHERE seller_id = u.id AND status IN ('moderation','awaiting_payment','active')) AS ads_n "
                 f"FROM users AS u{clause.replace('name', 'u.name').replace('phone_masked', 'u.phone_masked').replace('roles', 'u.roles').replace('CAST(id', 'CAST(u.id')} "
                 f"ORDER BY u.id DESC LIMIT {PER_PAGE} OFFSET {off}", params)
    return render_template("admin/users.html", rows=rows, q=q, role=role, page=page, pages=pages, total=total,
                           is_blocked=logic.is_blocked)


@bp.route("/users/<int:uid>/<action>", methods=["POST"])
def user_action(uid, action):
    conn = get_db()
    with tx(conn):
        u = conn.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
        if u is None:
            abort(404)
        if action == "add_seller":
            conn.execute("UPDATE users SET roles = roles | 2 WHERE id = ?", (uid,))
            log(conn, "grant_seller", user_id=uid)
            flash("Роль продавца выдана (пользователю нужно подтвердить номер).", "success")
        elif action == "remove_seller":
            # СВЯЗИ: users 1—N ads (seller_id): при снятии роли продавца все его объявления удаляются (по ТЗ).
            n = conn.execute("UPDATE ads SET status = 'deleted' WHERE seller_id = ? AND status <> 'deleted'", (uid,)).rowcount
            conn.execute("UPDATE reservations SET status = 'cancelled' WHERE status IN ('requested','confirmed') "
                         "AND ad_id IN (SELECT id FROM ads WHERE seller_id = ?)", (uid,))
            conn.execute("UPDATE users SET roles = (roles & ~2) | 1 WHERE id = ?", (uid,))       # остаётся покупателем
            logic.notify(conn, uid, "Администратор снял с вас роль продавца, ваши объявления удалены.")
            log(conn, "revoke_seller", user_id=uid, details=f"удалено объявлений: {n}")
            flash(f"Роль продавца снята, удалено объявлений: {n}.", "success")
        elif action == "make_admin":
            conn.execute("UPDATE users SET roles = roles | 4 WHERE id = ?", (uid,))
            log(conn, "grant_admin", user_id=uid)
            flash("Пользователь назначен администратором.", "success")
        elif action == "remove_admin":
            if uid == g.user["id"]:
                flash("Нельзя снять права администратора с самого себя.", "error")
            else:
                conn.execute("UPDATE users SET roles = roles & ~4 WHERE id = ?", (uid,))
                log(conn, "revoke_admin", user_id=uid)
                flash("Права администратора сняты.", "success")
        elif action == "block":
            days = request.form.get("days", "7")
            if days == "forever":
                conn.execute("UPDATE users SET blocked_forever = 1 WHERE id = ?", (uid,))
            else:
                conn.execute("UPDATE users SET blocked_until = ? WHERE id = ?",
                             (fmt(now() + timedelta(days=int(days) if days.isdigit() and 0 < int(days) <= 365 else 7)), uid))
            logic.notify(conn, uid, "Ваш аккаунт продавца заблокирован администратором.")
            log(conn, "block_seller", user_id=uid, details=days)
            flash("Продавец заблокирован: его объявления скрыты, новые создать нельзя.", "success")
        elif action == "unblock":
            conn.execute("UPDATE users SET blocked_forever = 0, blocked_until = NULL WHERE id = ?", (uid,))
            logic.notify(conn, uid, "Блокировка вашего аккаунта снята.")
            log(conn, "unblock_seller", user_id=uid)
            flash("Продавец разблокирован.", "success")
        else:
            abort(404)
    return redirect(request.form.get("back") or url_for("admin.users"))


@bp.route("/blocked")
def blocked():
    rows = q_all("SELECT * FROM users WHERE blocked_forever = 1 OR (blocked_until IS NOT NULL AND blocked_until > ?) ORDER BY id DESC",
                 (now_s(),))
    return render_template("admin/blocked.html", rows=rows)


# ----------------------------------------------------------------------------
# Поддержка (жалобы и вопросы)
# ----------------------------------------------------------------------------
@bp.route("/complaints", methods=["GET", "POST"])
def complaints():
    if request.method == "POST":
        cid, reply = request.form.get("id", type=int), request.form.get("reply", "").strip()
        c = q_one("SELECT * FROM complaints WHERE id = ?", (cid,))
        if c is None or len(reply) < 2:
            flash("Введите ответ.", "error")
        else:
            conn = get_db()
            with tx(conn):
                conn.execute("UPDATE complaints SET status = 'answered', admin_reply = ?, answered_at = ? WHERE id = ?", (reply, now_s(), cid))
                logic.notify(conn, c["user_id"], f"Ответ поддержки: {reply}", "/help")
                log(conn, "answer_complaint", c["ad_id"], c["user_id"], reply[:200])
            flash("Ответ отправлен пользователю.", "success")
        return redirect(url_for("admin.complaints"))
    # СВЯЗИ: complaints N—1 users (user_id), N—1 ads (ad_id, может быть пустым — LEFT JOIN).
    rows = q_all("SELECT c.*, u.name AS user_name, a.title AS ad_title FROM (complaints AS c INNER JOIN users AS u ON u.id = c.user_id) "
                 "LEFT JOIN ads AS a ON a.id = c.ad_id ORDER BY (c.status = 'new') DESC, c.id DESC LIMIT 200")
    return render_template("admin/complaints.html", rows=rows)


# ----------------------------------------------------------------------------
# Платежи: отчёт и экспорт
# ----------------------------------------------------------------------------
def _period():
    d_to = request.args.get("to") or date.today().isoformat()
    d_from = request.args.get("from") or (date.today() - timedelta(days=29)).isoformat()
    try:
        datetime.strptime(d_from, "%Y-%m-%d"), datetime.strptime(d_to, "%Y-%m-%d")
    except ValueError:
        d_from, d_to = (date.today() - timedelta(days=29)).isoformat(), date.today().isoformat()
    return d_from, d_to, f"{d_from} 00:00:00", f"{d_to} 23:59:59"


@bp.route("/payments")
def payments():
    d_from, d_to, lo, hi = _period()
    by_day = q_all("SELECT substr(paid_at, 1, 10) AS day, COUNT(*) AS n, SUM(amount) AS total FROM payments "
                   "WHERE status = 'paid' AND paid_at BETWEEN ? AND ? GROUP BY day ORDER BY day DESC", (lo, hi))
    # СВЯЗИ: payments N—1 ads (ad_id), ads N—1 users (seller_id): поступления по продавцам.
    by_seller = q_all("SELECT u.id AS id, u.name AS name, COUNT(p.id) AS n, SUM(p.amount) AS total "
                      "FROM (payments AS p INNER JOIN ads AS a ON a.id = p.ad_id) INNER JOIN users AS u ON u.id = a.seller_id "
                      "WHERE p.status = 'paid' AND p.paid_at BETWEEN ? AND ? GROUP BY u.id, u.name ORDER BY total DESC", (lo, hi))
    rows = q_all("SELECT p.*, a.title AS title, u.name AS seller_name FROM (payments AS p INNER JOIN ads AS a ON a.id = p.ad_id) "
                 "INNER JOIN users AS u ON u.id = a.seller_id WHERE p.created_at BETWEEN ? AND ? ORDER BY p.id DESC LIMIT 100", (lo, hi))
    total = sum(r["total"] or 0 for r in by_day)
    return render_template("admin/payments.html", by_day=by_day, by_seller=by_seller, rows=rows, total=total,
                           d_from=d_from, d_to=d_to)


@bp.route("/payments.csv")
def payments_csv():
    """Экспорт отчёта в CSV (открывается в Excel: кодировка UTF-8 с BOM, разделитель «;»)."""
    d_from, d_to, lo, hi = _period()
    rows = q_all("SELECT p.id AS id, p.paid_at AS paid_at, p.amount AS amount, p.external_tx_id AS tx, p.purpose AS purpose, "
                 "a.id AS ad_id, u.name AS seller FROM (payments AS p INNER JOIN ads AS a ON a.id = p.ad_id) "
                 "INNER JOIN users AS u ON u.id = a.seller_id WHERE p.status = 'paid' AND p.paid_at BETWEEN ? AND ? ORDER BY p.paid_at", (lo, hi))
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["№ платежа", "Дата оплаты", "Сумма, ₽", "ID транзакции", "Назначение", "№ объявления", "Продавец"])
    for r in rows:
        w.writerow([r["id"], r["paid_at"], str(r["amount"]).replace(".", ","), r["tx"], r["purpose"], r["ad_id"], r["seller"]])
    return Response("\ufeff" + buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=payments_{d_from}_{d_to}.csv"})


# ----------------------------------------------------------------------------
# Справочники: категории, локации
# ----------------------------------------------------------------------------
@bp.route("/categories", methods=["GET", "POST"])
def categories():
    conn = get_db()
    if request.method == "POST":
        action, name = request.form.get("action"), request.form.get("name", "").strip()
        cid, order = request.form.get("id", type=int), request.form.get("sort_order", type=int)
        try:
            if action == "add" and 2 <= len(name) <= 40:
                conn.execute("INSERT INTO categories(name, sort_order) VALUES (?,?)", (name, order or 500))
                log(conn, "category_add", details=name)
                flash("Категория добавлена.", "success")
            elif action == "save" and cid and 2 <= len(name) <= 40:
                conn.execute("UPDATE categories SET name = ?, sort_order = ? WHERE id = ?", (name, order or 100, cid))
                flash("Категория сохранена.", "success")
            elif action == "delete" and cid:
                # СВЯЗИ: categories 1—N ads (category_id): категорию с объявлениями удалить нельзя.
                if q_val("SELECT COUNT(*) FROM ads WHERE category_id = ?", (cid,)):
                    flash("В категории есть объявления — удалить её нельзя.", "error")
                else:
                    conn.execute("DELETE FROM categories WHERE id = ?", (cid,))
                    log(conn, "category_delete", details=str(cid))
                    flash("Категория удалена.", "success")
            else:
                flash("Название категории — от 2 до 40 символов.", "error")
        except Exception:
            flash("Категория с таким названием уже есть.", "error")
        return redirect(url_for("admin.categories"))
    rows = q_all("SELECT c.*, (SELECT COUNT(*) FROM ads WHERE category_id = c.id) AS n FROM categories AS c ORDER BY c.sort_order")
    return render_template("admin/categories.html", rows=rows)


@bp.route("/locations", methods=["GET", "POST"])
def locations():
    conn = get_db()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "delete":
            lid = request.form.get("id", type=int)
            # СВЯЗИ: locations используется в seller_locations, buyer_locations, ad_locations и как parent_id (район -> город).
            used = (q_val("SELECT COUNT(*) FROM seller_locations WHERE location_id = ?", (lid,)) +
                    q_val("SELECT COUNT(*) FROM buyer_locations WHERE location_id = ?", (lid,)) +
                    q_val("SELECT COUNT(*) FROM ad_locations WHERE location_id = ?", (lid,)) +
                    q_val("SELECT COUNT(*) FROM locations WHERE parent_id = ?", (lid,)))
            if used:
                flash("Локация используется (у пользователей, объявлений или как город района) — удалить нельзя.", "error")
            else:
                conn.execute("DELETE FROM locations WHERE id = ?", (lid,))
                log(conn, "location_delete", details=str(lid))
                flash("Локация удалена.", "success")
        else:
            kind, name = request.form.get("kind"), request.form.get("name", "").strip()
            parent = request.form.get("parent_id", type=int)
            try:
                lat, lon = float(request.form.get("lat", "").replace(",", ".")), float(request.form.get("lon", "").replace(",", "."))
                pop = request.form.get("population", type=int)
            except ValueError:
                lat = lon = pop = None
            if kind not in ("city", "district", "settlement") or not 2 <= len(name) <= 80 or lat is None:
                flash("Заполните тип, название и координаты.", "error")
            elif kind == "district" and not q_one("SELECT 1 FROM locations WHERE id = ? AND kind = 'city'", (parent,)):
                flash("Для района выберите город.", "error")
            else:
                conn.execute("INSERT INTO locations(kind, name, lat, lon, parent_id, population) VALUES (?,?,?,?,?,?)",
                             (kind, name, lat, lon, parent if kind == "district" else None, pop))
                log(conn, "location_add", details=f"{kind}: {name}")
                flash("Локация добавлена в справочник.", "success")
        return redirect(url_for("admin.locations"))
    rows = q_all("SELECT l.*, p.name AS parent_name FROM locations AS l LEFT JOIN locations AS p ON p.id = l.parent_id "
                 "ORDER BY COALESCE(p.name, l.name), l.kind <> 'city', l.name")
    return render_template("admin/locations.html", rows=rows, cities=[r for r in rows if r["kind"] == "city"])


# ----------------------------------------------------------------------------
# Рассылка и журнал
# ----------------------------------------------------------------------------
@bp.route("/broadcast", methods=["GET", "POST"])
def broadcast():
    if request.method == "POST":
        text = request.form.get("text", "").strip()
        if not 5 <= len(text) <= 1000:
            flash("Текст рассылки — от 5 до 1000 символов.", "error")
        else:
            conn = get_db()
            with tx(conn):
                ids = [r["id"] for r in conn.execute("SELECT id FROM users").fetchall()]
                for uid in ids:
                    logic.notify(conn, uid, f"Сообщение от администрации: {text}")
                conn.execute("INSERT INTO broadcasts(admin_id, text, sent_to, created_at) VALUES (?,?,?,?)",
                             (g.user["id"], text, len(ids), now_s()))
                log(conn, "broadcast", details=f"{len(ids)} получателей: {text[:100]}")
            flash(f"Рассылка отправлена: {len(ids)} получателей.", "success")
        return redirect(url_for("admin.broadcast"))
    # СВЯЗИ: broadcasts N—1 users (admin_id): кто отправил.
    rows = q_all("SELECT b.*, u.name AS admin_name FROM broadcasts AS b INNER JOIN users AS u ON u.id = b.admin_id ORDER BY b.id DESC LIMIT 20")
    return render_template("admin/broadcast.html", rows=rows, total_users=q_val("SELECT COUNT(*) FROM users"))


@bp.route("/log")
def moderation_log():
    # СВЯЗИ: moderation_log N—1 users (moderator_id) и N—1 ads/users (ad_id, user_id — необязательные, LEFT JOIN).
    rows = q_all("SELECT l.*, m.name AS moderator, a.title AS ad_title, t.name AS target FROM "
                 "(((moderation_log AS l INNER JOIN users AS m ON m.id = l.moderator_id) "
                 "LEFT JOIN ads AS a ON a.id = l.ad_id) LEFT JOIN users AS t ON t.id = l.user_id) ORDER BY l.id DESC LIMIT 200")
    return render_template("admin/log.html", rows=rows)
