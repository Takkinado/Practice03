"""Покупатель: каталог с гео-фильтром, карточка объявления, резерв, избранное, прокси-чат, жалобы."""
from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

import logic
from auth import login_required
from db import get_db, now, now_s, fmt, q_all, q_one, q_val, tx

bp = Blueprint("shop", __name__)
PER_PAGE = 12


def visible_where():
    """Условие «объявление видно покупателям»: активно и продавец не заблокирован."""
    # СВЯЗИ: ads N—1 users (seller_id): объявления заблокированного продавца из каталога скрываются.
    return ("a.status = 'active' AND u.blocked_forever = 0 AND (u.blocked_until IS NULL OR u.blocked_until <= ?)")


ADS_SELECT = ("SELECT a.*, c.name AS category_name, u.name AS seller_name, u.farm_name AS farm_name "
              "FROM ((ads AS a INNER JOIN categories AS c ON c.id = a.category_id) "
              "INNER JOIN users AS u ON u.id = a.seller_id) ")


@bp.route("/catalog")
@login_required
def catalog():
    loc_ids = logic.buyer_location_ids(g.user["id"])
    cat_id = request.args.get("category", type=int)
    sort = request.args.get("sort", "new")
    fav = request.args.get("fav") == "1"
    where, params = [visible_where()], [now_s()]
    if loc_ids:
        # СВЯЗИ: ads M—N locations через ad_locations: хотя бы одна локация продавца совпадает с локацией покупателя
        # (или с соседним НП — соседей добавляет logic.buyer_location_ids).
        marks = ",".join("?" * len(loc_ids))
        where.append(f"EXISTS (SELECT 1 FROM ad_locations AS al WHERE al.ad_id = a.id AND al.location_id IN ({marks}))")
        params += list(loc_ids)
    else:
        where.append("1 = 0")
    if cat_id:
        where.append("a.category_id = ?")
        params.append(cat_id)
    if fav:
        # СВЯЗИ: ads 1—N favorites (ad_id): только избранное текущего пользователя.
        where.append("a.id IN (SELECT ad_id FROM favorites WHERE user_id = ?)")
        params.append(g.user["id"])
    order = {"price_asc": "a.price ASC", "price_desc": "a.price DESC"}.get(sort, "a.activated_at DESC, a.id DESC")
    clause = " WHERE " + " AND ".join(where)
    total = q_val("SELECT COUNT(*) FROM (ads AS a INNER JOIN users AS u ON u.id = a.seller_id)" + clause, params)
    page, pages, offset = logic.paginate(total, request.args.get("page", 1, type=int), PER_PAGE)
    rows = q_all(ADS_SELECT + clause + f" ORDER BY {order} LIMIT {PER_PAGE} OFFSET {offset}", params)
    # СВЯЗИ: categories 1—N ads: счётчики по категориям для навигации (учитывают гео-фильтр покупателя).
    cats = q_all("SELECT c.id AS id, c.name AS name FROM categories AS c ORDER BY c.sort_order")
    my_locs = q_all("SELECT l.name AS name FROM buyer_locations AS bl INNER JOIN locations AS l ON l.id = bl.location_id "
                    "WHERE bl.user_id = ?", (g.user["id"],))
    favs = {r["ad_id"] for r in q_all("SELECT ad_id FROM favorites WHERE user_id = ?", (g.user["id"],))}
    return render_template("catalog.html", ads=logic.decorate_ads(rows), cats=cats, cat_id=cat_id, sort=sort, fav=fav,
                           page=page, pages=pages, total=total, my_locs=my_locs, favs=favs, no_locs=not loc_ids)


def get_ad_or_404(ad_id, allow_owner=True):
    ad = q_one(ADS_SELECT + "WHERE a.id = ?", (ad_id,))
    if ad is None:
        abort(404)
    owner = g.user and (g.user["id"] == ad["seller_id"] or g.user["roles"] & logic.ROLE_ADMIN)
    if ad["status"] != "active" and not (owner and allow_owner):
        abort(404)
    return ad


@bp.route("/ad/<int:ad_id>")
@login_required
def ad_card(ad_id):
    ad = get_ad_or_404(ad_id)
    photos = q_all("SELECT file_path FROM ad_photos WHERE ad_id = ? ORDER BY position", (ad_id,))
    seller = q_one("SELECT id, name, farm_name, public_phone, avatar_path, created_at FROM users WHERE id = ?", (ad["seller_id"],))
    d = logic.decorate_ads([ad])[0]
    my_res = q_one("SELECT * FROM reservations WHERE ad_id = ? AND buyer_id = ? AND status IN ('requested','confirmed') "
                   "ORDER BY id DESC", (ad_id, g.user["id"]))
    fav = bool(q_one("SELECT 1 FROM favorites WHERE user_id = ? AND ad_id = ?", (g.user["id"], ad_id)))
    return render_template("ad.html", ad=d, photos=photos, seller=seller, my_res=my_res, fav=fav,
                           own=ad["seller_id"] == g.user["id"])


@bp.route("/ad/<int:ad_id>/favorite", methods=["POST"])
@login_required
def favorite(ad_id):
    get_ad_or_404(ad_id)
    conn = get_db()
    if q_one("SELECT 1 FROM favorites WHERE user_id = ? AND ad_id = ?", (g.user["id"], ad_id)):
        conn.execute("DELETE FROM favorites WHERE user_id = ? AND ad_id = ?", (g.user["id"], ad_id))
        flash("Убрано из избранного.", "success")
    else:
        conn.execute("INSERT INTO favorites VALUES (?,?)", (g.user["id"], ad_id))
        flash("Добавлено в избранное: напомним, когда размещение будет заканчиваться.", "success")
    return redirect(request.form.get("back") or url_for("shop.ad_card", ad_id=ad_id))


# ----------------------------------------------------------------------------
# Резерв товара
# ----------------------------------------------------------------------------
@bp.route("/ad/<int:ad_id>/reserve", methods=["POST"])
@login_required
def reserve(ad_id):
    if not g.user["roles"] & logic.ROLE_BUYER:
        flash("Для резерва подключите роль покупателя в профиле.", "error")
        return redirect(url_for("profile"))
    conn = get_db()
    try:
        qty = float(request.form.get("quantity", "").replace(",", "."))
    except ValueError:
        qty = 0
    with tx(conn):                         # проверка остатка и вставка — атомарно (два покупателя не займут один остаток)
        ad = conn.execute("SELECT * FROM ads WHERE id = ?", (ad_id,)).fetchone()
        if ad is None or ad["status"] != "active":
            abort(404)
        # СВЯЗИ: reservations N—1 ads (ad_id) и N—1 users (buyer_id): у покупателя не больше одного открытого резерва на товар.
        busy = conn.execute("SELECT 1 FROM reservations WHERE ad_id = ? AND buyer_id = ? AND status IN ('requested','confirmed')",
                            (ad_id, g.user["id"])).fetchone()
        free = logic.available_qty(conn, ad)
        if ad["seller_id"] == g.user["id"]:
            flash("Нельзя резервировать собственный товар.", "error")
        elif qty <= 0 or qty > 100000:
            flash("Укажите количество больше нуля.", "error")
        elif busy:
            flash("У вас уже есть открытый резерв на этот товар.", "error")
        elif free is not None and qty > free:
            flash(f"Доступно только {free:g} {ad['unit']}: остальное зарезервировано.", "error")
        else:
            conn.execute("INSERT INTO reservations(ad_id, buyer_id, quantity, status, created_at, expires_at) VALUES (?,?,?,?,?,?)",
                         (ad_id, g.user["id"], qty, "requested", now_s(), fmt(now() + logic.RESERVE_ANSWER_TIME)))
            logic.notify(conn, ad["seller_id"],
                         f"Покупатель {g.user['name']} хочет зарезервировать {qty:g} {ad['unit']} «{ad['title']}».",
                         "/seller/reservations")
            flash("Запрос отправлен продавцу. Он должен ответить в течение часа.", "success")
    return redirect(url_for("shop.ad_card", ad_id=ad_id))


@bp.route("/my/reservations")
@login_required
def my_reservations():
    # СВЯЗИ: reservations N—1 ads (ad_id), ads N—1 users (seller_id): мои резервы с товаром и продавцом.
    rows = q_all("SELECT r.*, a.title AS title, a.unit AS unit, a.id AS ad_id, u.name AS seller_name "
                 "FROM (reservations AS r INNER JOIN ads AS a ON a.id = r.ad_id) INNER JOIN users AS u ON u.id = a.seller_id "
                 "WHERE r.buyer_id = ? ORDER BY r.id DESC LIMIT 100", (g.user["id"],))
    return render_template("my_reservations.html", rows=rows)


@bp.route("/my/reservations/<int:rid>/cancel", methods=["POST"])
@login_required
def cancel_reservation(rid):
    r = q_one("SELECT * FROM reservations WHERE id = ? AND buyer_id = ? AND status IN ('requested','confirmed')", (rid, g.user["id"]))
    if r is None:
        abort(404)
    get_db().execute("UPDATE reservations SET status = 'cancelled' WHERE id = ?", (rid,))
    flash("Резерв отменён.", "success")
    return redirect(url_for("shop.my_reservations"))


# ----------------------------------------------------------------------------
# Жалобы
# ----------------------------------------------------------------------------
@bp.route("/ad/<int:ad_id>/complain", methods=["POST"])
@login_required
def complain(ad_id):
    get_ad_or_404(ad_id)
    text = request.form.get("text", "").strip()
    if not 5 <= len(text) <= 1500:
        flash("Опишите жалобу (от 5 до 1500 символов).", "error")
    else:
        get_db().execute("INSERT INTO complaints(user_id, ad_id, kind, text, created_at) VALUES (?,?, 'complaint', ?, ?)",
                         (g.user["id"], ad_id, text, now_s()))
        flash("Жалоба отправлена администратору.", "success")
    return redirect(url_for("shop.ad_card", ad_id=ad_id))


# ----------------------------------------------------------------------------
# Прокси-чат (номера телефонов не раскрываются)
# ----------------------------------------------------------------------------
@bp.route("/ad/<int:ad_id>/chat", methods=["POST"])
@login_required
def start_chat(ad_id):
    ad = get_ad_or_404(ad_id)
    if ad["seller_id"] == g.user["id"]:
        flash("Это ваше собственное объявление.", "error")
        return redirect(url_for("shop.ad_card", ad_id=ad_id))
    conn = get_db()
    chat = q_one("SELECT id FROM chats WHERE ad_id = ? AND buyer_id = ?", (ad_id, g.user["id"]))
    if chat is None:
        cid = conn.execute("INSERT INTO chats(ad_id, buyer_id, seller_id, created_at) VALUES (?,?,?,?)",
                           (ad_id, g.user["id"], ad["seller_id"], now_s())).lastrowid
    else:
        cid = chat["id"]
    return redirect(url_for("shop.chat", chat_id=cid))


@bp.route("/chats")
@login_required
def chats():
    # СВЯЗИ: chats N—1 ads (ad_id); chats N—1 users (buyer_id / seller_id): собеседник — «другая» сторона чата.
    rows = q_all("SELECT c.id AS id, a.title AS title, a.id AS ad_id, "
                 "CASE WHEN c.buyer_id = ? THEN s.name ELSE b.name END AS peer, "
                 "(SELECT text FROM messages WHERE chat_id = c.id ORDER BY id DESC LIMIT 1) AS last_text, "
                 "(SELECT created_at FROM messages WHERE chat_id = c.id ORDER BY id DESC LIMIT 1) AS last_at, "
                 "(SELECT COUNT(*) FROM messages WHERE chat_id = c.id AND is_read = 0 AND sender_id <> ?) AS unread "
                 "FROM (((chats AS c INNER JOIN ads AS a ON a.id = c.ad_id) INNER JOIN users AS b ON b.id = c.buyer_id) "
                 "INNER JOIN users AS s ON s.id = c.seller_id) WHERE c.buyer_id = ? OR c.seller_id = ? "
                 "ORDER BY last_at DESC", (g.user["id"],) * 4)
    return render_template("chats.html", rows=rows)


@bp.route("/chats/<int:chat_id>", methods=["GET", "POST"])
@login_required
def chat(chat_id):
    c = q_one("SELECT c.*, a.title AS title FROM chats AS c INNER JOIN ads AS a ON a.id = c.ad_id WHERE c.id = ?", (chat_id,))
    if c is None or g.user["id"] not in (c["buyer_id"], c["seller_id"]):
        abort(404)
    conn = get_db()
    peer_id = c["seller_id"] if g.user["id"] == c["buyer_id"] else c["buyer_id"]
    if request.method == "POST":
        text = request.form.get("text", "").strip()
        if not 1 <= len(text) <= 2000:
            flash("Сообщение должно быть от 1 до 2000 символов.", "error")
        else:
            conn.execute("INSERT INTO messages(chat_id, sender_id, text, created_at) VALUES (?,?,?,?)",
                         (chat_id, g.user["id"], text, now_s()))
            link = f"/chats/{chat_id}"
            if not q_one("SELECT 1 FROM notifications WHERE user_id = ? AND link = ? AND is_read = 0", (peer_id, link)):
                logic.notify(conn, peer_id, f"Новое сообщение в чате по объявлению «{c['title']}».", link)
        return redirect(url_for("shop.chat", chat_id=chat_id))
    conn.execute("UPDATE messages SET is_read = 1 WHERE chat_id = ? AND sender_id <> ?", (chat_id, g.user["id"]))
    conn.execute("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND link = ?", (g.user["id"], f"/chats/{chat_id}"))
    msgs = q_all("SELECT * FROM messages WHERE chat_id = ? ORDER BY id", (chat_id,))
    peer = q_one("SELECT name, farm_name FROM users WHERE id = ?", (peer_id,))
    return render_template("chat.html", chat=c, msgs=msgs, peer=peer)
