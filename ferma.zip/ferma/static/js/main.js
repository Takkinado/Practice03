document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('form[data-confirm]').forEach(f => f.addEventListener('submit', e => { if (!confirm(f.dataset.confirm)) e.preventDefault(); }));
  document.querySelectorAll('select[data-autosubmit],input[data-autosubmit]').forEach(el => el.addEventListener('change', () => el.form.submit()));
  // галерея и увеличение фото
  const lb = document.getElementById('lightbox');
  document.querySelectorAll('[data-zoom]').forEach(img => img.addEventListener('click', () => { lb.querySelector('img').src = img.dataset.zoom; lb.classList.add('on'); }));
  if (lb) lb.addEventListener('click', () => lb.classList.remove('on'));
  document.querySelectorAll('.thumbs img').forEach(t => t.addEventListener('click', () => { const b = document.querySelector('.gallery .big img'); b.src = t.src; b.dataset.zoom = t.src; }));
  // чат: прокрутка вниз и автообновление, пока поле ввода пустое
  const box = document.querySelector('.chat-box');
  if (box) { box.scrollTop = box.scrollHeight; const ta = document.querySelector('#chat-text'); setInterval(() => { if (!ta.value) location.reload(); }, 10000); }
});
