"""Подключение к БД SQLite, транзакции, создание структуры."""
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime

from flask import g

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("FERMA_DB", os.path.join(BASE_DIR, "database", "ferma.db"))
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")


def connect():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.isolation_level = None            # транзакциями управляем сами (см. tx)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def get_db():
    if "db" not in g:
        g.db = connect()
    return g.db


def close_db(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


@contextmanager
def tx(conn=None):
    """Атомарная транзакция (BEGIN IMMEDIATE защищает от гонок при резерве и оплате)."""
    conn = conn or get_db()
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise


def q_all(sql, params=()):
    return get_db().execute(sql, params).fetchall()


def q_one(sql, params=()):
    return get_db().execute(sql, params).fetchone()


def q_val(sql, params=(), default=0):
    row = get_db().execute(sql, params).fetchone()
    return row[0] if row and row[0] is not None else default


def now():
    return datetime.now().replace(microsecond=0)


def fmt(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def now_s():
    return fmt(now())


def init_db(reset=False):
    """Создаёт таблицы и, если база пустая, наполняет демо-данными."""
    if reset and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = connect()
    conn.execute("PRAGMA journal_mode = WAL")
    conn.executescript(open(SCHEMA_PATH, encoding="utf-8").read())
    if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        import seed
        seed.seed(conn)
    else:
        import seed
        seed.renew_demo_ads(conn)          # демо-объявления живут 24 ч — продлеваем для показа
    conn.close()
