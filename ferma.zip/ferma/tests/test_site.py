"""Сквозной тест «Фермы» на временной базе: python tests/test_site.py"""
import hashlib, hmac, io, json, os, re, sys, tempfile
os.environ["FERMA_DB"] = tempfile.mktemp(suffix=".db")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as A, logic
from db import connect
from PIL import Image

c = A.app.test_client()
db = connect()
tok = lambda h: re.search(r'name="_csrf" value="([^"]+)"', h).group(1)
get = lambda u: c.get(u, follow_redirects=True)
def post(u, data=None, page="/login", files=None):
    d = dict(data or {}); d["_csrf"] = tok(get(page).get_data(as_text=True))
    return c.post(u, data=d, follow_redirects=True, content_type="multipart/form-data" if files else None)
txt = lambda r: re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", r.get_data(as_text=True)))
def ok(cond, name):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond: sys.exit(1)
def login(phone, pw):
    c.post("/logout", data={"_csrf": tok(get("/login").get_data(as_text=True))})
    return post("/login", {"phone": phone, "password": pw}, "/login")
def logout(): c.post("/logout", data={"_csrf": tok(get("/login").get_data(as_text=True))})

for u in ["/", "/login", "/register"]: ok(get(u).status_code == 200, f"GET {u}")
ok(c.get("/catalog").status_code in (200, 302), "каталог доступен/требует входа")

# --- регистрация покупателя
r = post("/register", {"name": "Тест Покупатель", "phone": "+7 900 777-77-77", "password": "secret1", "password2": "secret1", "role": "buyer"}, "/register")
ok(db.execute("select roles from users where name='Тест Покупатель'").fetchone()[0] == 1, "регистрация покупателя (роль 1)")
ok("+7 900 777-77-77" not in db.execute("select phone_hash||phone_masked from users where name='Тест Покупатель'").fetchone()[0], "телефон не хранится открыто")
logout()

# --- продавец создаёт объявление
login("+7 900 111-11-11", "seller123")
loc_ids = [r[0] for r in db.execute("select location_id from seller_locations where user_id=(select id from users where name='Иван Фермеров')")]
buf = io.BytesIO(); Image.new("RGB", (300, 200), (120, 180, 90)).save(buf, "JPEG"); buf.seek(0)
page = get("/seller/ads/new").get_data(as_text=True)
r = c.post("/seller/ads/new", data={"_csrf": tok(page), "title": "Тестовый мёд", "category_id": db.execute("select id from categories where name='Мёд'").fetchone()[0],
    "description": "Липовый мёд, свежий сбор", "price": "450", "unit": "кг", "stock": "10", "availability": "in_stock", "meeting": "both",
    "locations": [str(loc_ids[0])], "photos": (buf, "honey.jpg")}, content_type="multipart/form-data", follow_redirects=True)
ad = db.execute("select * from ads where title='Тестовый мёд'").fetchone()
ok(ad and ad["status"] == "moderation", "объявление создано, статус «На модерации»")
ok(db.execute("select count(*) from ad_photos where ad_id=?", (ad["id"],)).fetchone()[0] == 1, "фото сохранено")
logout()

# --- модератор одобряет
login("+7 900 000-00-01", "admin123")
for u in ["/admin/", "/admin/moderation", f"/admin/moderation/{ad['id']}", "/admin/users", "/admin/blocked", "/admin/complaints",
          "/admin/payments", "/admin/categories", "/admin/locations", "/admin/broadcast", "/admin/log", "/admin/payments.csv"]:
    ok(get(u).status_code == 200, f"admin GET {u}")
r = post(f"/admin/moderation/{ad['id']}/approve", page=f"/admin/moderation/{ad['id']}")
ok(db.execute("select status from ads where id=?", (ad["id"],)).fetchone()[0] == "awaiting_payment", "одобрено -> «Ожидает оплаты»")
logout()

# --- оплата: webhook с подписью
login("+7 900 111-11-11", "seller123")
post(f"/seller/ads/{ad['id']}/pay", page=f"/seller/ads/{ad['id']}/pay")
ok(get(f"/seller/ads/{ad['id']}/pay").status_code == 200, "страница оплаты (QR + реквизиты)")
body = json.dumps({"tx_id": "T-1", "purpose": f"Оплата объявления №{ad['id']}", "amount": 9, "status": "success"}).encode()
ok(c.post("/webhook/payment", data=body).status_code == 403, "webhook без подписи отклонён")
sig = hmac.new(logic.WEBHOOK_SECRET, body, hashlib.sha256).hexdigest()
r = c.post("/webhook/payment", data=body, headers={"X-Signature": sig})
ok(r.status_code == 200, "webhook с верной подписью принят")
a = db.execute("select * from ads where id=?", (ad["id"],)).fetchone()
ok(a["status"] == "active" and a["expires_at"], "оплата -> «Активно», запущен таймер 24 ч")
ok(c.post("/webhook/payment", data=body, headers={"X-Signature": sig}).get_json().get("duplicate"), "повтор webhook не дублирует платёж")
logout()

# --- покупатель: каталог, резерв, чат
login("+7 900 333-33-33", "buyer123")
cat = txt(get("/catalog")); ok("Помидоры" in cat or "Мёд" in cat, "каталог показывает объявления")
cat_ads = txt(get("/catalog?category=%d" % db.execute("select id from categories where name='Мёд'").fetchone()[0]))
ok("Тестовый мёд" in cat_ads, "фильтр по категории + локация покупателя (Ленинский район)")
r = post(f"/ad/{ad['id']}/reserve", {"quantity": "2"}, f"/ad/{ad['id']}")
ok(db.execute("select status from reservations where ad_id=?", (ad["id"],)).fetchone()[0] == "requested", "резерв создан (ждёт продавца)")
post(f"/ad/{ad['id']}/chat", {"text": "Здравствуйте! Мёд ещё есть?"}, f"/ad/{ad['id']}")
ok(db.execute("select count(*) from messages").fetchone()[0] >= 1, "сообщение в прокси-чате отправлено")
logout()

login("+7 900 111-11-11", "seller123")
rid = db.execute("select id from reservations where ad_id=?", (ad["id"],)).fetchone()[0]
post(f"/seller/reservations/{rid}/confirm", page="/seller/reservations")
ok(db.execute("select status from reservations where id=?", (rid,)).fetchone()[0] == "confirmed", "продавец подтвердил резерв (3 часа)")
ok(db.execute("select count(*) from notifications where text like '%резерв%'").fetchone()[0] >= 2, "уведомления о резерве созданы")
for u in ["/seller/ads", f"/seller/ads/{ad['id']}", "/seller/reservations", "/chats", "/notifications", "/profile", "/locations", "/help"]:
    ok(get(u).status_code == 200, f"seller GET {u}")
logout()

# --- права
login("+7 900 333-33-33", "buyer123")
ok(c.get("/admin/").status_code == 403, "покупатель не попадает в админку")
ok(c.get("/seller/ads").status_code in (302, 403), "покупатель не попадает в кабинет продавца")
ic = db.execute("pragma integrity_check").fetchone()[0]; fk = db.execute("pragma foreign_key_check").fetchall()
ok(ic == "ok" and not fk, "целостность БД: integrity_check и foreign_key_check")
print("ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ")
