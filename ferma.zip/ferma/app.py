"""«Ферма» — маркетплейс локальных продуктов (сайт вместо бота: Flask + SQLite).

Запуск:  python app.py     (http://127.0.0.1:5000)
Админ-панель и модерация: /admin (только роль «администратор»).
"""
import os
import random
import secrets
from datetime import date, datetime, timedelta

from flask import (Flask, abort, flash, g, jsonify, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import auth
import logic
import media
from admin import bp as admin_bp
from auth import login_required
from db import (BASE_DIR, close_db, fmt, get_db, init_db, now, now_s, q_all, q_one, q_val, tx)
from seller import bp as seller_bp
from shop import bp as shop_bp

SITE_NAME = "Ферма"
app = Flask(__name__)


def _secret_key():
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    folder = os.path.join(BASE_DIR, "instance")
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "secret.key")
    if not os.path.exists(path):
        with open(path, "w") as fh:
            fh.write(secrets.token_hex(32))
    return open(path).read().strip()


app.config.update(SECRET_KEY=_secret_key(), SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 14, MAX_CONTENT_LENGTH=16 * 1024 * 1024)
app.teardown_appcontext(close_db)
for bp in (shop_bp, seller_bp, admin_bp):
    app.register_blueprint(bp)


# ----------------------------------------------------------------------------
# Фильтры и общие данные для шаблонов
# ----------------------------------------------------------------------------
@app.template_filter("has")
def f_has(roles, bit):
    """Проверка бита роли в маске: user.roles|has(ROLE_ADMIN)."""
    return bool(int(roles or 0) & bit)


@app.template_filter("dt")
def f_dt(v):
    return datetime.strptime(v[:19], "%Y-%m-%d %H:%M:%S").strftime("%d.%m.%Y %H:%M") if v else "—"


@app.template_filter("d")
def f_d(v):
    return datetime.strptime(v[:10], "%Y-%m-%d").strftime("%d.%m.%Y") if v else "—"


@app.template_filter("money")
def f_money(v):
    v = float(v or 0)
    return (f"{v:,.0f}" if v == int(v) else f"{v:,.2f}").replace(",", "\u00a0") + "\u00a0₽"


@app.template_filter("qty")
def f_qty(v):
    v = float(v or 0)
    return f"{v:g}".replace(".", ",")


@app.template_filter("left")
def f_left(v):
    """Сколько осталось до момента v: «5 ч 10 мин»."""
    if not v:
        return ""
    sec = int((datetime.strptime(v[:19], "%Y-%m-%d %H:%M:%S") - now()).total_seconds())
    if sec <= 0:
        return "истекло"
    h, m = sec // 3600, sec % 3600 // 60
    return f"{h} ч {m} мин" if h else f"{m} мин"


@app.context_processor
def inject():
    unread_notes = unread_msgs = 0
    if g.get("user"):
        unread_notes = q_val("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0", (g.user["id"],))
        # СВЯЗИ: messages N—1 chats (chat_id): непрочитанные сообщения в чатах, где пользователь — покупатель или продавец.
        unread_msgs = q_val("SELECT COUNT(*) FROM messages AS m INNER JOIN chats AS c ON c.id = m.chat_id "
                            "WHERE m.is_read = 0 AND m.sender_id <> ? AND (c.buyer_id = ? OR c.seller_id = ?)",
                            (g.user["id"], g.user["id"], g.user["id"]))
    return dict(csrf_token=auth.csrf_token, SITE=SITE_NAME, logic=logic, AD_STATUS=logic.AD_STATUS,
                RES_STATUS=logic.RES_STATUS, AVAIL=logic.AVAILABILITY, MEETING=logic.MEETING,
                unread_notes=unread_notes, unread_msgs=unread_msgs, ROLE_BUYER=logic.ROLE_BUYER,
                ROLE_SELLER=logic.ROLE_SELLER, ROLE_ADMIN=logic.ROLE_ADMIN, year=date.today().year)


@app.before_request
def before_request():
    logic.refresh(get_db())          # таймеры: истечение объявлений, оплата, резервы
    auth.load_user()
    auth.check_csrf()


@app.after_request
def headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    return resp


@app.errorhandler(403)
def e403(_):
    return render_template("error.html", code=403, text="Нет доступа к этой странице."), 403


@app.errorhandler(404)
def e404(_):
    return render_template("error.html", code=404, text="Страница не найдена."), 404


@app.errorhandler(400)
def e400(e):
    return render_template("error.html", code=400, text=getattr(e, "description", "Некорректный запрос.")), 400


@app.errorhandler(413)
def e413(_):
    return render_template("error.html", code=413, text="Файлы слишком большие (не более 16 МБ за запрос)."), 413


# ----------------------------------------------------------------------------
# Главная
# ----------------------------------------------------------------------------
@app.route("/")
def index():
    stats = dict(
        ads=q_val("SELECT COUNT(*) FROM ads WHERE status = 'active'"),
        sellers=q_val("SELECT COUNT(*) FROM users WHERE roles & 2 > 0"),
        locations=q_val("SELECT COUNT(*) FROM locations"),
    )
    # СВЯЗИ: categories 1—N ads (category_id): сколько активных объявлений в каждой категории.
    cats = q_all("SELECT c.id AS id, c.name AS name, COUNT(a.id) AS n FROM categories AS c "
                 "LEFT JOIN ads AS a ON a.category_id = c.id AND a.status = 'active' "
                 "GROUP BY c.id, c.name ORDER BY c.sort_order")
    return render_template("index.html", stats=stats, cats=cats)


# ----------------------------------------------------------------------------
# Регистрация / SMS-подтверждение / вход
# ----------------------------------------------------------------------------
def send_sms_code(conn, user_id):
    """Создаёт код подтверждения. Реального SMS-шлюза нет: в демо-режиме код показывается на сайте."""
    code = f"{random.randint(0, 999999):06d}"
    conn.execute("UPDATE sms_codes SET used = 1 WHERE user_id = ? AND used = 0", (user_id,))
    conn.execute("INSERT INTO sms_codes(user_id, code, created_at) VALUES (?,?,?)", (user_id, code, now_s()))
    return code


@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("index"))
    form = {}
    if request.method == "POST":
        form = {k: request.form.get(k, "").strip() for k in ("name", "phone", "role", "farm_name")}
        pw, pw2 = request.form.get("password", ""), request.form.get("password2", "")
        phone = logic.normalize_phone(form["phone"])
        roles = {"buyer": logic.ROLE_BUYER, "seller": logic.ROLE_SELLER,
                 "both": logic.ROLE_BUYER | logic.ROLE_SELLER}.get(form["role"])
        err = None
        if not logic.valid_name(form["name"]):
            err = "Укажите имя (от 2 символов)."
        elif not phone:
            err = "Введите корректный номер телефона, например +7 900 123-45-67."
        elif roles is None:
            err = "Выберите, кем вы будете: покупателем, продавцом или обоими."
        elif logic.check_password(pw):
            err = logic.check_password(pw)
        elif pw != pw2:
            err = "Пароли не совпадают."
        elif q_one("SELECT 1 FROM users WHERE phone_hash = ?", (logic.phone_hash(phone),)):
            err = "Этот номер уже зарегистрирован. Войдите в аккаунт."
        if err:
            flash(err, "error")
        else:
            avatar = request.files.get("avatar")
            conn = get_db()
            with tx(conn):
                uid = conn.execute(
                    "INSERT INTO users(name, phone_hash, phone_masked, password_hash, roles, farm_name, created_at) "
                    "VALUES (?,?,?,?,?,?,?)",
                    (form["name"], logic.phone_hash(phone), logic.mask_phone(phone), generate_password_hash(pw),
                     roles, (form["farm_name"][:100] or None) if roles & logic.ROLE_SELLER else None, now_s())).lastrowid
                code = send_sms_code(conn, uid) if roles & logic.ROLE_SELLER else None
            if avatar and avatar.filename:
                path, aerr = media.save_avatar(avatar, uid)
                if path:
                    conn.execute("UPDATE users SET avatar_path = ? WHERE id = ?", (path, uid))
                else:
                    flash(aerr, "error")
            session.clear()
            session["uid"] = uid
            session["mode"] = "seller" if roles & logic.ROLE_SELLER else "buyer"
            if code:
                flash(f"Демо-режим: SMS-шлюз не подключён, ваш код подтверждения — {code}.", "success")
                return redirect(url_for("confirm_phone"))
            flash("Регистрация прошла успешно. Выберите ваши локации, чтобы видеть товары рядом.", "success")
            return redirect(url_for("locations"))
    return render_template("register.html", form=form)


@app.route("/confirm-phone", methods=["GET", "POST"])
@login_required
def confirm_phone():
    """Для продавца номер подтверждается кодом из SMS (защита от мошенничества)."""
    if g.user["phone_confirmed"]:
        return redirect(url_for("seller.ads"))
    conn = get_db()
    if request.method == "POST":
        if request.form.get("resend"):
            code = send_sms_code(conn, g.user["id"])
            flash(f"Демо-режим: новый код — {code}.", "success")
            return redirect(url_for("confirm_phone"))
        row = q_one("SELECT * FROM sms_codes WHERE user_id = ? AND used = 0 ORDER BY id DESC LIMIT 1", (g.user["id"],))
        fresh = row and row["created_at"] >= fmt(now() - timedelta(minutes=10))
        if fresh and secrets.compare_digest(row["code"], request.form.get("code", "").strip()):
            with tx(conn):
                conn.execute("UPDATE sms_codes SET used = 1 WHERE id = ?", (row["id"],))
                conn.execute("UPDATE users SET phone_confirmed = 1 WHERE id = ?", (g.user["id"],))
            flash("Номер подтверждён. Теперь можно размещать объявления.", "success")
            return redirect(url_for("seller.ads"))
        flash("Неверный или просроченный код (код действует 10 минут).", "error")
    return render_template("confirm_phone.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("index"))
    nxt = auth.safe_next(request.values.get("next"))
    if request.method == "POST":
        phone = logic.normalize_phone(request.form.get("phone"))
        user = q_one("SELECT * FROM users WHERE phone_hash = ?", (logic.phone_hash(phone),)) if phone else None
        if user and check_password_hash(user["password_hash"], request.form.get("password", "")):
            session.clear()
            session["uid"] = user["id"]
            session.permanent = bool(request.form.get("remember"))
            return redirect(nxt or url_for("index"))
        flash("Неверный телефон или пароль.", "error")
    return render_template("login.html", next=nxt)


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("Вы вышли из аккаунта.", "success")
    return redirect(url_for("index"))


@app.route("/mode/<mode>", methods=["POST"])
@login_required
def switch_mode(mode):
    """Переключение «покупатель ↔ продавец» без повторной регистрации."""
    need = logic.ROLE_SELLER if mode == "seller" else logic.ROLE_BUYER if mode == "buyer" else None
    if need is None or not g.user["roles"] & need:
        abort(404)
    session["mode"] = mode
    return redirect(url_for("seller.ads") if mode == "seller" else url_for("shop.catalog"))


# ----------------------------------------------------------------------------
# Профиль
# ----------------------------------------------------------------------------
@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    conn = get_db()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "info":
            name = request.form.get("name", "").strip()
            pub = logic.normalize_phone(request.form.get("public_phone")) if request.form.get("public_phone", "").strip() else None
            if not logic.valid_name(name):
                flash("Укажите имя (от 2 символов).", "error")
            elif request.form.get("public_phone", "").strip() and not pub:
                flash("Контактный телефон указан неверно.", "error")
            else:
                farm = request.form.get("farm_name", "").strip()[:100] or None
                conn.execute("UPDATE users SET name = ?, farm_name = ?, public_phone = ? WHERE id = ?",
                             (name, farm if g.user["roles"] & logic.ROLE_SELLER else None, pub, g.user["id"]))
                f = request.files.get("avatar")
                if f and f.filename:
                    path, aerr = media.save_avatar(f, g.user["id"])
                    if path:
                        conn.execute("UPDATE users SET avatar_path = ? WHERE id = ?", (path, g.user["id"]))
                    else:
                        flash(aerr, "error")
                flash("Профиль сохранён.", "success")
        elif action == "password":
            new = request.form.get("new_password", "")
            if not check_password_hash(g.user["password_hash"], request.form.get("old_password", "")):
                flash("Текущий пароль неверен.", "error")
            elif logic.check_password(new):
                flash(logic.check_password(new), "error")
            elif new != request.form.get("new_password2", ""):
                flash("Новые пароли не совпадают.", "error")
            else:
                conn.execute("UPDATE users SET password_hash = ? WHERE id = ?", (generate_password_hash(new), g.user["id"]))
                flash("Пароль изменён.", "success")
        elif action == "add_role":
            flag = logic.ROLE_SELLER if request.form.get("role") == "seller" else logic.ROLE_BUYER
            conn.execute("UPDATE users SET roles = roles | ? WHERE id = ?", (flag, g.user["id"]))
            if flag == logic.ROLE_SELLER and not g.user["phone_confirmed"]:
                flash(f"Демо-режим: код подтверждения номера — {send_sms_code(conn, g.user['id'])}.", "success")
                return redirect(url_for("confirm_phone"))
            flash("Роль подключена. Переключайтесь между ролями в меню.", "success")
        return redirect(url_for("profile"))
    return render_template("profile.html")


# ----------------------------------------------------------------------------
# Локации (покупатель: 1–5, продавец: до 10)
# ----------------------------------------------------------------------------
@app.route("/locations", methods=["GET", "POST"])
@login_required
def locations():
    conn = get_db()
    seller_mode = g.mode == "seller"
    limit = logic.MAX_SELLER_LOCS if seller_mode else logic.MAX_BUYER_LOCS
    table = "seller_locations" if seller_mode else "buyer_locations"
    if request.method == "POST":
        action = request.form.get("action")
        count = q_val(f"SELECT COUNT(*) FROM {table} WHERE user_id = ?", (g.user["id"],))
        if action == "delete":
            lid = request.form.get("location_id", type=int)
            if not seller_mode and count <= 1:
                flash("У покупателя должна остаться хотя бы одна локация.", "error")
            else:
                conn.execute(f"DELETE FROM {table} WHERE user_id = ? AND location_id = ?", (g.user["id"], lid))
                flash("Локация удалена.", "success")
        elif action in ("add", "custom"):
            if count >= limit:
                flash(f"Можно указать не более {limit} локаций.", "error")
                return redirect(url_for("locations"))
            note = request.form.get("note", "").strip()[:150] or None
            if action == "custom":                       # свой населённый пункт: точка на карте + описание
                name = request.form.get("name", "").strip()
                try:
                    lat, lon = float(request.form.get("lat", "").replace(",", ".")), float(request.form.get("lon", "").replace(",", "."))
                except ValueError:
                    lat = lon = None
                if not (2 <= len(name) <= 80) or lat is None or not (-90 <= lat <= 90 and -180 <= lon <= 180):
                    flash("Укажите название и корректные координаты (широта, долгота).", "error")
                    return redirect(url_for("locations"))
                with tx(conn):
                    lid = conn.execute("INSERT INTO locations(kind, name, lat, lon) VALUES ('settlement',?,?,?)",
                                       (name, lat, lon)).lastrowid
                    # СВЯЗИ: location_neighbors (location_id <-> neighbor_id): соседи нового НП — симметрично.
                    for nid in request.form.getlist("neighbors", type=int):
                        if nid != lid and q_one("SELECT 1 FROM locations WHERE id = ?", (nid,)):
                            conn.execute("INSERT OR IGNORE INTO location_neighbors VALUES (?,?)", (lid, nid))
                            conn.execute("INSERT OR IGNORE INTO location_neighbors VALUES (?,?)", (nid, lid))
            else:
                lid = request.form.get("location_id", type=int)
            loc = q_one("SELECT * FROM locations WHERE id = ?", (lid,))
            if loc is None:
                flash("Выберите локацию из списка.", "error")
            elif seller_mode and logic.is_big_city(loc):
                flash("Крупный город: выберите район (продавцу нужна конкретная точка продажи).", "error")
            elif q_one(f"SELECT 1 FROM {table} WHERE user_id = ? AND location_id = ?", (g.user["id"], lid)):
                flash("Эта локация уже добавлена.", "error")
            else:
                if seller_mode:
                    conn.execute("INSERT INTO seller_locations(user_id, location_id, note) VALUES (?,?,?)", (g.user["id"], lid, note))
                else:
                    conn.execute("INSERT INTO buyer_locations(user_id, location_id) VALUES (?,?)", (g.user["id"], lid))
                flash("Локация добавлена.", "success")
        return redirect(url_for("locations"))
    # СВЯЗИ: <seller|buyer>_locations N—1 locations (location_id); locations.parent_id -> locations.id (район -> город).
    if seller_mode:
        mine = q_all("SELECT l.id AS id, l.name AS name, l.kind AS kind, p.name AS parent, sl.note AS note, l.lat AS lat, l.lon AS lon "
                     "FROM (seller_locations AS sl INNER JOIN locations AS l ON l.id = sl.location_id) "
                     "LEFT JOIN locations AS p ON p.id = l.parent_id WHERE sl.user_id = ? ORDER BY l.name", (g.user["id"],))
    else:
        mine = q_all("SELECT l.id AS id, l.name AS name, l.kind AS kind, p.name AS parent, NULL AS note, l.lat AS lat, l.lon AS lon "
                     "FROM (buyer_locations AS bl INNER JOIN locations AS l ON l.id = bl.location_id) "
                     "LEFT JOIN locations AS p ON p.id = l.parent_id WHERE bl.user_id = ? ORDER BY l.name", (g.user["id"],))
    all_locs = q_all("SELECT l.id AS id, l.name AS name, l.kind AS kind, l.population AS population, p.name AS parent "
                     "FROM locations AS l LEFT JOIN locations AS p ON p.id = l.parent_id ORDER BY COALESCE(p.name, l.name), l.kind <> 'city', l.name")
    have = {r["id"] for r in mine}
    options = [r for r in all_locs if r["id"] not in have and not (seller_mode and r["kind"] == "city" and (r["population"] or 0) > logic.BIG_CITY_POPULATION)]
    settlements = [r for r in all_locs if r["kind"] == "settlement"]
    return render_template("locations.html", mine=mine, options=options, settlements=settlements, limit=limit,
                           seller_mode=seller_mode)


# ----------------------------------------------------------------------------
# Уведомления, помощь, webhook платёжного провайдера
# ----------------------------------------------------------------------------
@app.route("/notifications", methods=["GET", "POST"])
@login_required
def notifications():
    if request.method == "POST":
        get_db().execute("UPDATE notifications SET is_read = 1 WHERE user_id = ?", (g.user["id"],))
        return redirect(url_for("notifications"))
    rows = q_all("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100", (g.user["id"],))
    return render_template("notifications.html", rows=rows)


@app.route("/notifications/<int:nid>")
@login_required
def open_notification(nid):
    n = q_one("SELECT * FROM notifications WHERE id = ? AND user_id = ?", (nid, g.user["id"]))
    if n is None:
        abort(404)
    get_db().execute("UPDATE notifications SET is_read = 1 WHERE id = ?", (nid,))
    return redirect(auth.safe_next(n["link"]) or url_for("notifications"))


@app.route("/help", methods=["GET", "POST"])
@login_required
def help_page():
    if request.method == "POST":
        text = request.form.get("text", "").strip()
        if not 5 <= len(text) <= 1500:
            flash("Опишите вопрос (от 5 до 1500 символов).", "error")
        else:
            get_db().execute("INSERT INTO complaints(user_id, kind, text, created_at) VALUES (?, 'help', ?, ?)",
                             (g.user["id"], text, now_s()))
            flash("Обращение отправлено администратору. Ответ придёт в уведомления.", "success")
            return redirect(url_for("help_page"))
    mine = q_all("SELECT * FROM complaints WHERE user_id = ? AND kind = 'help' ORDER BY id DESC", (g.user["id"],))
    return render_template("help.html", mine=mine)


@app.route("/webhook/payment", methods=["POST"])
def payment_webhook():
    """Webhook платёжного провайдера СБП: подпись HMAC-SHA256 в заголовке X-Signature, номер объявления — в purpose."""
    conn = get_db()
    with tx(conn):
        status, payload = logic.process_payment_webhook(conn, request.get_data(), request.headers.get("X-Signature", ""))
    return jsonify(payload), status


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=os.environ.get("FLASK_DEBUG") == "1")
else:
    init_db()
