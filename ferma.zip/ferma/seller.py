"""Продавец: создание объявлений, модерация-оплата-активация, продление, копирование, заявки на резерв."""
import json
import os
import secrets
import shutil

from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

import logic
import media
from auth import role_required
from db import BASE_DIR, fmt, get_db, now, now_s, q_all, q_one, q_val, tx

bp = Blueprint("seller", __name__, url_prefix="/seller")


@bp.before_request
def _guard():
    """Раздел только для продавцов с подтверждённым телефоном (SMS-код)."""
    if g.get("user") is None:
        return role_required(logic.ROLE_SELLER)(lambda: None)()
    if not g.user["roles"] & logic.ROLE_SELLER:
        return role_required(logic.ROLE_SELLER)(lambda: None)()
    if not g.user["phone_confirmed"]:
        flash("Сначала подтвердите номер телефона кодом из SMS.", "error")
        return redirect(url_for("confirm_phone"))
    return None


def own_ad(ad_id):
    ad = q_one("SELECT * FROM ads WHERE id = ? AND seller_id = ?", (ad_id, g.user["id"]))
    if ad is None:
        abort(404)
    return ad


def seller_locs():
    # СВЯЗИ: seller_locations N—1 locations (location_id), locations.parent_id -> locations.id: подписи «Город, Район».
    return q_all("SELECT l.id AS id, l.name AS name, p.name AS parent, sl.note AS note "
                 "FROM (seller_locations AS sl INNER JOIN locations AS l ON l.id = sl.location_id) "
                 "LEFT JOIN locations AS p ON p.id = l.parent_id WHERE sl.user_id = ? ORDER BY l.name", (g.user["id"],))


# ----------------------------------------------------------------------------
# Список и создание
# ----------------------------------------------------------------------------
@bp.route("/ads")
def ads():
    status = request.args.get("status", "")
    params, sql = [g.user["id"]], ("SELECT a.*, c.name AS category_name, "
                                   "(SELECT file_path FROM ad_photos WHERE ad_id = a.id ORDER BY position LIMIT 1) AS photo "
                                   "FROM ads AS a INNER JOIN categories AS c ON c.id = a.category_id "   # СВЯЗИ: ads N—1 categories
                                   "WHERE a.seller_id = ? AND a.status <> 'deleted'")
    if status in logic.AD_STATUS:
        sql += " AND a.status = ?"
        params.append(status)
    rows = q_all(sql + " ORDER BY a.id DESC", params)
    counts = {r["status"]: r["n"] for r in q_all(
        "SELECT status, COUNT(*) AS n FROM ads WHERE seller_id = ? AND status <> 'deleted' GROUP BY status", (g.user["id"],))}
    return render_template("seller/ads.html", rows=rows, status=status, counts=counts,
                           open_count=logic.open_ads_count(g.user["id"]), blocked=logic.is_blocked(g.user))


def parse_form(locs):
    """Читает и проверяет поля формы объявления. Возвращает (данные, ошибка)."""
    f = request.form
    d = dict(title=f.get("title", "").strip(), description=f.get("description", "").strip(),
             category_id=f.get("category_id", type=int), unit=f.get("unit"), availability=f.get("availability"),
             meeting=f.get("meeting"), loc_ids=[x for x in f.getlist("locations", type=int) if x in {l["id"] for l in locs}])
    try:
        d["price"] = float(f.get("price", "").replace(",", "."))
    except ValueError:
        d["price"] = 0
    raw = f.get("stock", "").strip()
    try:
        d["stock"] = float(raw.replace(",", ".")) if raw else None
    except ValueError:
        d["stock"] = -1
    if not 3 <= len(d["title"]) <= 100:
        return d, "Название товара — от 3 до 100 символов."
    if not q_one("SELECT 1 FROM categories WHERE id = ?", (d["category_id"],)):
        return d, "Выберите категорию товара."
    if not 10 <= len(d["description"]) <= 1500:
        return d, "Описание — от 10 до 1500 символов."
    if not 0 < d["price"] < 1_000_000:
        return d, "Укажите цену больше нуля."
    if d["unit"] not in logic.UNITS:
        return d, "Выберите единицу измерения."
    if d["stock"] is not None and not 0 <= d["stock"] <= 1_000_000:
        return d, "Количество должно быть неотрицательным числом."
    if d["availability"] not in logic.AVAILABILITY or d["meeting"] not in logic.MEETING:
        return d, "Укажите наличие и способ встречи."
    if not d["loc_ids"]:
        return d, "Выберите хотя бы одну локацию продажи."
    return d, None


def submit(conn, ad_id, d, seller_id):
    """Автопремодерация: запрещённые слова — сразу «Отклонено», иначе «На модерации»."""
    problem = logic.premoderation_problem(d["title"], d["description"])
    if problem:
        conn.execute("UPDATE ads SET status = 'rejected', reject_reason = ? WHERE id = ?", (problem, ad_id))
        logic.notify(conn, seller_id, f"Объявление «{d['title']}» отклонено автоматически: {problem}", f"/seller/ads/{ad_id}")
        return False
    conn.execute("UPDATE ads SET status = 'moderation', reject_reason = NULL, moderator_id = NULL WHERE id = ?", (ad_id,))
    logic.notify(conn, seller_id, f"Объявление «{d['title']}» (№{ad_id}) отправлено на проверку.", f"/seller/ads/{ad_id}")
    return True


@bp.route("/ads/new", methods=["GET", "POST"])
def ad_new():
    locs = seller_locs()
    if not locs:
        flash("Сначала добавьте хотя бы одну локацию продажи.", "error")
        return redirect(url_for("locations"))
    if logic.is_blocked(g.user):
        flash("Ваш аккаунт продавца заблокирован — создавать объявления нельзя.", "error")
        return redirect(url_for("seller.ads"))
    d = {"loc_ids": [], "availability": "in_stock", "meeting": "both", "unit": "кг"}
    if request.method == "POST":
        d, err = parse_form(locs)
        photos = None
        if not err:
            photos, err = media.read_photos(request.files.getlist("photos"))
        if not err and logic.open_ads_count(g.user["id"]) >= logic.MAX_OPEN_ADS:
            err = f"Достигнут лимит: не более {logic.MAX_OPEN_ADS} активных объявлений одновременно."
        if err:
            flash(err, "error")
        else:
            conn = get_db()
            with tx(conn):
                ad_id = conn.execute(
                    "INSERT INTO ads(seller_id, category_id, title, description, price, unit, stock, availability, meeting, status, created_at) "
                    "VALUES (?,?,?,?,?,?,?,?,?, 'moderation', ?)",
                    (g.user["id"], d["category_id"], d["title"], d["description"], d["price"], d["unit"], d["stock"],
                     d["availability"], d["meeting"], now_s())).lastrowid
                # СВЯЗИ: ads M—N locations через ad_locations; ads 1—N ad_photos (ad_id).
                for lid in d["loc_ids"]:
                    conn.execute("INSERT INTO ad_locations VALUES (?,?)", (ad_id, lid))
                for pos, path in enumerate(media.save_photos(photos, ad_id), 1):
                    conn.execute("INSERT INTO ad_photos(ad_id, file_path, position) VALUES (?,?,?)", (ad_id, path, pos))
                ok = submit(conn, ad_id, d, g.user["id"])
            flash("Объявление отправлено на модерацию." if ok else "Объявление отклонено автопроверкой — причина в карточке.",
                  "success" if ok else "error")
            return redirect(url_for("seller.ad_view", ad_id=ad_id))
    return render_template("seller/ad_form.html", d=d, locs=locs, edit=False,
                           cats=q_all("SELECT * FROM categories ORDER BY sort_order"))


@bp.route("/ads/<int:ad_id>/edit", methods=["GET", "POST"])
def ad_edit(ad_id):
    ad = own_ad(ad_id)
    if ad["status"] != "rejected":
        flash("Редактировать можно только отклонённое объявление (активное — только удалить).", "error")
        return redirect(url_for("seller.ad_view", ad_id=ad_id))
    locs = seller_locs()
    d = dict(ad)
    d["loc_ids"] = [r["location_id"] for r in q_all("SELECT location_id FROM ad_locations WHERE ad_id = ?", (ad_id,))]
    if request.method == "POST":
        d, err = parse_form(locs)
        photos = None
        files = [f for f in request.files.getlist("photos") if f and f.filename]
        if not err and files:
            photos, err = media.read_photos(files)
        if not err and logic.open_ads_count(g.user["id"]) >= logic.MAX_OPEN_ADS:
            err = f"Достигнут лимит: не более {logic.MAX_OPEN_ADS} активных объявлений одновременно."
        if err:
            flash(err, "error")
        else:
            conn = get_db()
            with tx(conn):
                conn.execute("UPDATE ads SET category_id=?, title=?, description=?, price=?, unit=?, stock=?, availability=?, meeting=? "
                             "WHERE id = ?", (d["category_id"], d["title"], d["description"], d["price"], d["unit"], d["stock"],
                                              d["availability"], d["meeting"], ad_id))
                conn.execute("DELETE FROM ad_locations WHERE ad_id = ?", (ad_id,))
                for lid in d["loc_ids"]:
                    conn.execute("INSERT INTO ad_locations VALUES (?,?)", (ad_id, lid))
                if photos:
                    conn.execute("DELETE FROM ad_photos WHERE ad_id = ?", (ad_id,))
                    for pos, path in enumerate(media.save_photos(photos, ad_id), 1):
                        conn.execute("INSERT INTO ad_photos(ad_id, file_path, position) VALUES (?,?,?)", (ad_id, path, pos))
                ok = submit(conn, ad_id, d, g.user["id"])
            flash("Отправлено на повторную модерацию." if ok else "Снова отклонено автопроверкой.", "success" if ok else "error")
            return redirect(url_for("seller.ad_view", ad_id=ad_id))
    return render_template("seller/ad_form.html", d=d, locs=locs, edit=True, ad=ad,
                           cats=q_all("SELECT * FROM categories ORDER BY sort_order"))


@bp.route("/ads/<int:ad_id>")
def ad_view(ad_id):
    ad = own_ad(ad_id)
    cat = q_val("SELECT name FROM categories WHERE id = ?", (ad["category_id"],), "")
    photos = q_all("SELECT file_path FROM ad_photos WHERE ad_id = ? ORDER BY position", (ad_id,))
    pays = q_all("SELECT * FROM payments WHERE ad_id = ? ORDER BY id DESC", (ad_id,))     # СВЯЗИ: payments N—1 ads (ad_id)
    res = q_val("SELECT COUNT(*) FROM reservations WHERE ad_id = ? AND status IN ('requested','confirmed')", (ad_id,))
    moderator = q_val("SELECT name FROM users WHERE id = ?", (ad["moderator_id"],), None) if ad["moderator_id"] else None
    return render_template("seller/ad_view.html", ad=ad, cat=cat, photos=photos, pays=pays, res=res,
                           locs=logic.ad_locations_text(ad_id), can_pay=logic.can_pay(ad), moderator=moderator)


@bp.route("/ads/<int:ad_id>/delete", methods=["POST"])
def ad_delete(ad_id):
    ad = own_ad(ad_id)
    if ad["status"] == "deleted":
        abort(404)
    conn = get_db()
    with tx(conn):
        conn.execute("UPDATE ads SET status = 'deleted' WHERE id = ?", (ad_id,))
        # СВЯЗИ: reservations N—1 ads (ad_id): резервы удалённого товара отменяются, покупатели получают уведомление.
        for r in conn.execute("SELECT id, buyer_id FROM reservations WHERE ad_id = ? AND status IN ('requested','confirmed')", (ad_id,)).fetchall():
            conn.execute("UPDATE reservations SET status = 'cancelled' WHERE id = ?", (r["id"],))
            logic.notify(conn, r["buyer_id"], f"Резерв отменён: продавец удалил объявление «{ad['title']}».")
    flash("Объявление удалено. Оплата за размещение не возвращается.", "success")
    return redirect(url_for("seller.ads"))


@bp.route("/ads/<int:ad_id>/copy", methods=["POST"])
def ad_copy(ad_id):
    """Истёкшее объявление копируется в новое (с повторной модерацией и оплатой)."""
    ad = own_ad(ad_id)
    if ad["status"] != "expired":
        flash("Копировать можно только истёкшие объявления.", "error")
        return redirect(url_for("seller.ad_view", ad_id=ad_id))
    if logic.open_ads_count(g.user["id"]) >= logic.MAX_OPEN_ADS:
        flash(f"Достигнут лимит: не более {logic.MAX_OPEN_ADS} активных объявлений одновременно.", "error")
        return redirect(url_for("seller.ad_view", ad_id=ad_id))
    conn = get_db()
    with tx(conn):
        new_id = conn.execute(
            "INSERT INTO ads(seller_id, category_id, title, description, price, unit, stock, availability, meeting, status, created_at) "
            "SELECT seller_id, category_id, title, description, price, unit, stock, availability, meeting, 'moderation', ? "
            "FROM ads WHERE id = ?", (now_s(), ad_id)).lastrowid
        # СВЯЗИ: копируются связи нового объявления: ad_locations (только локации, которые ещё есть у продавца) и ad_photos.
        conn.execute("INSERT INTO ad_locations SELECT ?, al.location_id FROM ad_locations AS al "
                     "INNER JOIN seller_locations AS sl ON sl.location_id = al.location_id AND sl.user_id = ? WHERE al.ad_id = ?",
                     (new_id, g.user["id"], ad_id))
        for p in conn.execute("SELECT file_path, position FROM ad_photos WHERE ad_id = ?", (ad_id,)).fetchall():
            src = os.path.join(BASE_DIR, "static", p["file_path"])
            ext = p["file_path"].rsplit(".", 1)[-1]
            rel = f"uploads/ads/{new_id}/{p['position']}_{secrets.token_hex(4)}.{ext}"
            os.makedirs(os.path.dirname(os.path.join(BASE_DIR, "static", rel)), exist_ok=True)
            if os.path.exists(src):
                shutil.copyfile(src, os.path.join(BASE_DIR, "static", rel))
                conn.execute("INSERT INTO ad_photos(ad_id, file_path, position) VALUES (?,?,?)", (new_id, rel, p["position"]))
        if not conn.execute("SELECT 1 FROM ad_locations WHERE ad_id = ?", (new_id,)).fetchone():
            raise_msg = True
        else:
            raise_msg = False
        if raise_msg:                      # ни одной из прежних локаций у продавца не осталось
            conn.execute("DELETE FROM ads WHERE id = ?", (new_id,))
    if raise_msg:
        flash("У вас больше нет локаций из этого объявления. Создайте новое объявление.", "error")
        return redirect(url_for("seller.ad_view", ad_id=ad_id))
    with tx(conn):
        row = conn.execute("SELECT title, description FROM ads WHERE id = ?", (new_id,)).fetchone()
        submit(conn, new_id, row, g.user["id"])
    flash("Создана копия — она ушла на модерацию.", "success")
    return redirect(url_for("seller.ad_view", ad_id=new_id))


# ----------------------------------------------------------------------------
# Оплата размещения 9 ₽ (СБП): QR-код, реквизиты, webhook
# ----------------------------------------------------------------------------
@bp.route("/ads/<int:ad_id>/pay", methods=["POST"])
def pay_start(ad_id):
    ad = own_ad(ad_id)
    if not logic.can_pay(ad):
        flash("Это объявление сейчас нельзя оплатить (оно должно быть одобрено модератором).", "error")
        return redirect(url_for("seller.ad_view", ad_id=ad_id))
    if logic.is_blocked(g.user):
        flash("Аккаунт продавца заблокирован.", "error")
        return redirect(url_for("seller.ad_view", ad_id=ad_id))
    conn = get_db()
    with tx(conn):
        if not logic.PAID_MODE:                                   # «первый год бесплатно»
            logic.activate_ad(conn, ad_id)
            conn.execute("INSERT INTO payments(ad_id, amount, status, external_tx_id, purpose, created_at, paid_at) "
                         "VALUES (?, 0, 'paid', ?, ?, ?, ?)", (ad_id, f"free-{secrets.token_hex(6)}", logic.payment_purpose(ad_id), now_s(), now_s()))
            flash("Размещение бесплатное в первый год: объявление активно на 24 часа.", "success")
            return redirect(url_for("seller.ad_view", ad_id=ad_id))
        pay = conn.execute("SELECT * FROM payments WHERE ad_id = ? AND status = 'pending' ORDER BY id DESC", (ad_id,)).fetchone()
        if pay is None:
            pid = conn.execute("INSERT INTO payments(ad_id, amount, status, purpose, created_at) VALUES (?,?, 'pending', ?, ?)",
                               (ad_id, logic.AD_PRICE_RUB, logic.payment_purpose(ad_id), now_s())).lastrowid
            rel = f"qr/ad{ad_id}_p{pid}.png"
            logic.make_qr_png(logic.sbp_payload(ad_id), os.path.join(BASE_DIR, "static", rel))
            conn.execute("UPDATE payments SET qr_url = ? WHERE id = ?", (rel, pid))
    return redirect(url_for("seller.pay_page", ad_id=ad_id))


@bp.route("/ads/<int:ad_id>/pay")
def pay_page(ad_id):
    ad = own_ad(ad_id)
    pay = q_one("SELECT * FROM payments WHERE ad_id = ? AND status = 'pending' ORDER BY id DESC", (ad_id,))
    if pay is None:
        return redirect(url_for("seller.ad_view", ad_id=ad_id))
    return render_template("seller/pay.html", ad=ad, pay=pay, recipient=logic.PAY_RECIPIENT, account=logic.PAY_ACCOUNT,
                           purpose=logic.payment_purpose(ad_id), payload=logic.sbp_payload(ad_id),
                           wait_until=fmt(logic.datetime.strptime(pay["created_at"], "%Y-%m-%d %H:%M:%S") + logic.PAYMENT_WAIT),
                           demo=logic.DEMO_PAYMENTS)


@bp.route("/ads/<int:ad_id>/pay/simulate", methods=["POST"])
def pay_simulate(ad_id):
    """Демо: имитирует webhook банка (с настоящей подписью) — так проверяется весь путь оплаты."""
    own_ad(ad_id)
    if not logic.DEMO_PAYMENTS:
        abort(404)
    ok = request.form.get("result") != "fail"
    body = json.dumps({"tx_id": f"demo-{secrets.token_hex(6)}", "purpose": logic.payment_purpose(ad_id),
                       "amount": logic.AD_PRICE_RUB, "status": "success" if ok else "failed"}).encode()
    conn = get_db()
    with tx(conn):
        status, payload = logic.process_payment_webhook(conn, body, logic.sign_body(body))
    flash("Платёж получен — объявление активно на 24 часа." if ok and payload.get("ok") else
          f"Платёж не принят: {payload.get('error', 'ошибка')}.", "success" if ok and payload.get("ok") else "error")
    return redirect(url_for("seller.ad_view", ad_id=ad_id))


# ----------------------------------------------------------------------------
# Заявки на резерв
# ----------------------------------------------------------------------------
@bp.route("/reservations")
def reservations():
    # СВЯЗИ: reservations N—1 ads (ad_id) и N—1 users (buyer_id): заявки покупателей на мои товары.
    rows = q_all("SELECT r.*, a.title AS title, a.unit AS unit, a.id AS ad_id, u.name AS buyer_name "
                 "FROM (reservations AS r INNER JOIN ads AS a ON a.id = r.ad_id) INNER JOIN users AS u ON u.id = r.buyer_id "
                 "WHERE a.seller_id = ? ORDER BY (r.status = 'requested') DESC, r.id DESC LIMIT 100", (g.user["id"],))
    return render_template("seller/reservations.html", rows=rows)


@bp.route("/reservations/<int:rid>/<action>", methods=["POST"])
def reservation_answer(rid, action):
    if action not in ("confirm", "reject"):
        abort(404)
    conn = get_db()
    with tx(conn):
        r = conn.execute("SELECT r.*, a.title AS title, a.unit AS unit, a.stock AS stock, a.id AS aid FROM reservations AS r "
                         "INNER JOIN ads AS a ON a.id = r.ad_id WHERE r.id = ? AND a.seller_id = ?", (rid, g.user["id"])).fetchone()
        if r is None:
            abort(404)
        if r["status"] != "requested":
            flash("На эту заявку уже нельзя ответить (срок вышел или она закрыта).", "error")
        elif action == "reject":
            conn.execute("UPDATE reservations SET status = 'rejected' WHERE id = ?", (rid,))
            logic.notify(conn, r["buyer_id"], f"Продавец отказал в резерве «{r['title']}».", f"/ad/{r['aid']}")
            flash("Отказ отправлен покупателю.", "success")
        else:
            free = logic.available_qty(conn, conn.execute("SELECT * FROM ads WHERE id = ?", (r["aid"],)).fetchone())
            if free is not None and r["quantity"] > free:
                flash(f"Недостаточно товара: свободно {free:g} {r['unit']}.", "error")
            else:
                conn.execute("UPDATE reservations SET status = 'confirmed', confirmed_at = ?, expires_at = ? WHERE id = ?",
                             (now_s(), fmt(now() + logic.RESERVE_HOLD_TIME), rid))
                logic.notify(conn, r["buyer_id"], f"Продавец подтвердил резерв «{r['title']}» на 3 часа.", f"/ad/{r['aid']}")
                flash("Резерв подтверждён на 3 часа.", "success")
    return redirect(url_for("seller.reservations"))
