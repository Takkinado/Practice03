"""Вход, роли, режим «покупатель / продавец», CSRF."""
import secrets
from functools import wraps
from urllib.parse import urlparse

from flask import abort, flash, g, redirect, request, session, url_for

import logic
from db import now_s, q_one


def load_user():
    """Кладёт текущего пользователя в g.user (или None) и определяет режим."""
    g.user = None
    uid = session.get("uid")
    if not uid:
        return
    user = q_one("SELECT * FROM users WHERE id = ?", (uid,))
    if user is None:
        session.clear()
        return
    g.user = user
    mode = session.get("mode")
    if mode == "seller" and user["roles"] & logic.ROLE_SELLER:
        g.mode = "seller"
    elif mode == "buyer" and user["roles"] & logic.ROLE_BUYER:
        g.mode = "buyer"
    else:
        g.mode = "seller" if user["roles"] & logic.ROLE_SELLER else "buyer"


def role_required(flag):
    """Доступ только вошедшим пользователям с нужной ролью (битовая маска)."""
    def decorator(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if g.user is None:
                flash("Войдите в аккаунт, чтобы продолжить.", "error")
                return redirect(url_for("login", next=request.path if request.method == "GET" else None))
            if not g.user["roles"] & flag:
                if flag == logic.ROLE_ADMIN:
                    abort(403)
                name = "покупателя" if flag == logic.ROLE_BUYER else "продавца"
                flash(f"Для этого раздела нужна роль {name}. Подключите её в профиле.", "error")
                return redirect(url_for("profile"))
            return view(*args, **kwargs)
        return wrapper
    return decorator


def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if g.user is None:
            flash("Войдите в аккаунт, чтобы продолжить.", "error")
            return redirect(url_for("login", next=request.path if request.method == "GET" else None))
        return view(*args, **kwargs)
    return wrapper


def safe_next(target):
    """Редирект после входа — только на внутренние страницы сайта."""
    if not target:
        return None
    parts = urlparse(target)
    if parts.scheme or parts.netloc or not target.startswith("/") or target.startswith("//"):
        return None
    return target


def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


def check_csrf():
    # Webhook платёжного провайдера защищён подписью, а не CSRF-токеном
    if request.method == "POST" and not request.path.startswith("/webhook/"):
        sent = request.form.get("_csrf", "")
        if not sent or not secrets.compare_digest(sent, session.get("_csrf", "")):
            abort(400, "Сессия формы устарела. Обновите страницу и повторите.")
