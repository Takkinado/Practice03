"""Демо-данные «Фермы». Телефоны и адреса выдуманные; фото — сгенерированные заглушки."""
import os
import random
from datetime import timedelta

from werkzeug.security import generate_password_hash

import logic
from db import BASE_DIR, fmt, now

UPLOADS = os.path.join(BASE_DIR, "static", "uploads")

CATEGORIES = ["Овощи", "Фрукты", "Ягоды", "Мясо", "Птица", "Молочное", "Яйца", "Мёд",
              "Хлеб и выпечка", "Бакалея", "Напитки", "Другое"]
CAT_COLORS = {"Овощи": (76, 160, 70), "Фрукты": (214, 110, 60), "Ягоды": (170, 50, 90), "Мясо": (160, 70, 60),
              "Птица": (212, 160, 70), "Молочное": (110, 150, 200), "Яйца": (200, 170, 110), "Мёд": (225, 160, 30),
              "Хлеб и выпечка": (170, 120, 70), "Бакалея": (140, 130, 100), "Напитки": (60, 150, 150),
              "Другое": (120, 120, 120)}

# (name, kind, lat, lon, parent, population)
CITIES = [("Ростов-на-Дону", "city", 47.2357, 39.7015, None, 1137904),
          ("Краснодар", "city", 45.0355, 38.9753, None, 1138654)]
DISTRICTS = {"Ростов-на-Дону": [("Ленинский район", 47.2150, 39.7180), ("Октябрьский район", 47.2480, 39.8030),
                                ("Первомайский район", 47.2730, 39.7850), ("Пролетарский район", 47.1960, 39.7520),
                                ("Советский район", 47.2120, 39.6600), ("Кировский район", 47.2300, 39.7150),
                                ("Ворошиловский район", 47.2800, 39.7050), ("Железнодорожный район", 47.2400, 39.7250)],
             "Краснодар": [("Западный округ", 45.0540, 38.9350), ("Карасунский округ", 45.0430, 39.0700),
                           ("Прикубанский округ", 45.1100, 38.9800), ("Центральный округ", 45.0400, 38.9760)]}
SETTLEMENTS = [("Аксай", 47.2672, 39.8692, 44000), ("Батайск", 47.1393, 39.7457, 122000),
               ("Новочеркасск", 47.4112, 40.1043, 160000), ("Багаевская", 47.3240, 40.3770, 9000),
               ("Персиановский", 47.4467, 40.0572, 7500), ("Азов", 47.1122, 39.4232, 81000),
               ("Динская", 45.2200, 39.2300, 33000), ("Елизаветинская", 45.0700, 38.8400, 6500)]
NEIGHBORS = [("Аксай", "Новочеркасск"), ("Аксай", "Батайск"), ("Новочеркасск", "Персиановский"),
             ("Новочеркасск", "Багаевская"), ("Батайск", "Азов"), ("Динская", "Елизаветинская")]


def _font(size):
    from PIL import ImageFont
    for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "C:/Windows/Fonts/arialbd.ttf",
              "C:/Windows/Fonts/arial.ttf", "/Library/Fonts/Arial Bold.ttf"):
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def make_photo(path, title, category, variant=0):
    """Рисует фото-заглушку: градиент цвета категории, круги и название товара."""
    from PIL import Image, ImageDraw
    w, h = 800, 600
    base = CAT_COLORS.get(category, (120, 120, 120))
    img = Image.new("RGB", (w, h))
    d = ImageDraw.Draw(img)
    for y in range(h):
        f = 1.1 - 0.4 * y / h
        d.line([(0, y), (w, y)], fill=tuple(min(255, int(c * f)) for c in base))
    rnd = random.Random(hash(title) % 10_000 + variant)
    for _ in range(9):
        r = rnd.randint(40, 140)
        x, y = rnd.randint(0, w), rnd.randint(0, h)
        shade = tuple(min(255, c + rnd.randint(15, 70)) for c in base)
        d.ellipse([x - r, y - r, x + r, y + r], fill=shade)
    d.rectangle([0, h - 120, w, h], fill=(0, 0, 0))
    f_big, f_small = _font(46), _font(26)
    d.text((36, h - 105), title[:28], font=f_big, fill=(255, 255, 255))
    d.text((36, h - 48), f"{category} · Ферма (демо-фото {variant + 1})", font=f_small, fill=(230, 230, 230))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path, "JPEG", quality=85)


def seed(conn):
    t = now()
    ts = lambda delta=timedelta(0): fmt(t + delta)
    conn.execute("BEGIN")

    # --- справочники
    for i, name in enumerate(CATEGORIES, 1):
        conn.execute("INSERT INTO categories(name, sort_order) VALUES (?,?)", (name, i * 10))
    cat = {r["name"]: r["id"] for r in conn.execute("SELECT id, name FROM categories")}

    loc = {}
    for name, kind, lat, lon, parent, pop in CITIES:
        loc[name] = conn.execute("INSERT INTO locations(kind, name, lat, lon, parent_id, population) VALUES (?,?,?,?,?,?)",
                                 (kind, name, lat, lon, parent, pop)).lastrowid
    for city, rows in DISTRICTS.items():
        for name, lat, lon in rows:
            loc[f"{city}|{name}"] = conn.execute(
                "INSERT INTO locations(kind, name, lat, lon, parent_id) VALUES ('district',?,?,?,?)",
                (name, lat, lon, loc[city])).lastrowid
    for name, lat, lon, pop in SETTLEMENTS:
        loc[name] = conn.execute("INSERT INTO locations(kind, name, lat, lon, population) VALUES ('settlement',?,?,?,?)",
                                 (name, lat, lon, pop)).lastrowid
    for a, b in NEIGHBORS:                        # связь соседства симметрична
        conn.execute("INSERT INTO location_neighbors VALUES (?,?)", (loc[a], loc[b]))
        conn.execute("INSERT INTO location_neighbors VALUES (?,?)", (loc[b], loc[a]))
    L = lambda city, d: loc[f"{city}|{d}"]
    RND, KRD = "Ростов-на-Дону", "Краснодар"

    # --- пользователи
    def user(name, phone, pw, roles, farm=None, confirmed=1):
        p = logic.normalize_phone(phone)
        return conn.execute(
            "INSERT INTO users(name, phone_hash, phone_masked, password_hash, roles, farm_name, phone_confirmed, created_at) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (name, logic.phone_hash(p), logic.mask_phone(p), generate_password_hash(pw), roles, farm, confirmed,
             ts(-timedelta(days=20)))).lastrowid
    admin = user("Администратор Ферма", "+7 900 000-00-01", "admin123", 5)
    s1 = user("Иван Фермеров", "+7 900 111-11-11", "seller123", 3, "Ферма «Зелёный Дон»")
    s2 = user("Мария Пасечникова", "+7 900 222-22-22", "seller123", 2, "Пасека у реки")
    s3 = user("Пётр Кубанский", "+7 900 555-55-55", "seller123", 2, "Подворье «Кубань»")
    b1 = user("Анна Покупателева", "+7 900 333-33-33", "buyer123", 1)
    b2 = user("Олег Соседов", "+7 900 444-44-44", "buyer123", 1)

    for u, rows in {s1: [(L(RND, "Ленинский район"), "рынок «Привоз»"), (L(RND, "Октябрьский район"), None),
                         (loc["Аксай"], None)],
                    s2: [(loc["Новочеркасск"], "Центральный рынок"), (loc["Аксай"], None), (loc["Батайск"], None)],
                    s3: [(L(KRD, "Западный округ"), None), (L(KRD, "Центральный округ"), "ярмарка выходного дня")]}.items():
        for lid, note in rows:
            conn.execute("INSERT INTO seller_locations(user_id, location_id, note) VALUES (?,?,?)", (u, lid, note))
    conn.execute("INSERT INTO buyer_locations VALUES (?,?)", (b1, L(RND, "Ленинский район")))
    conn.execute("INSERT INTO buyer_locations VALUES (?,?)", (b2, loc["Аксай"]))
    conn.execute("INSERT INTO buyer_locations VALUES (?,?)", (s1, L(RND, "Ленинский район")))

    # --- объявления: (продавец, название, категория, описание, цена, ед., остаток, наличие, встреча, локации, статус)
    ads = [
        (s1, "Помидоры «Бычье сердце»", "Овощи", "Крупные сладкие помидоры с собственной грядки, без нитратов. Собираем утром в день продажи.", 180, "кг", 60, "in_stock", "both", [L(RND, "Ленинский район"), L(RND, "Октябрьский район")], "active"),
        (s1, "Огурцы грунтовые", "Овощи", "Хрустящие огурцы для салатов и засолки. Продаём ящиками и на вес.", 90, "кг", 100, "in_stock", "both", [L(RND, "Ленинский район"), loc["Аксай"]], "active"),
        (s1, "Картофель молодой", "Овощи", "Молодой картофель, мытый, сорт «Ред Скарлет». Мешки по 10 кг.", 45, "кг", 300, "in_stock", "pickup", [L(RND, "Октябрьский район")], "active"),
        (s2, "Яблоки «Семеренко»", "Фрукты", "Кисло-сладкие яблоки из собственного сада, долго хранятся.", 70, "кг", 200, "in_stock", "both", [loc["Новочеркасск"], loc["Аксай"]], "active"),
        (s2, "Клубника садовая", "Ягоды", "Ароматная клубника, собранная вчера вечером. Лотки по 1 кг.", 350, "кг", 25, "in_stock", "pickup", [loc["Аксай"], loc["Батайск"]], "active"),
        (s1, "Говядина охлаждённая", "Мясо", "Фермерская говядина, откорм на подножном корме. Вырезка, лопатка, фарш на заказ.", 650, "кг", 40, "in_stock", "delivery", [L(RND, "Ленинский район")], "active"),
        (s3, "Тушка бройлера", "Птица", "Домашние цыплята-бройлеры, охлаждённые, вес 2–2,5 кг.", 280, "кг", 50, "in_stock", "both", [L(KRD, "Западный округ")], "active"),
        (s2, "Козье молоко", "Молочное", "Свежее козье молоко, утренний удой. Тара — стеклянная банка.", 120, "л", 30, "in_stock", "pickup", [loc["Новочеркасск"]], "active"),
        (s1, "Яйца домашние С1", "Яйца", "Яйца от курочек свободного выгула, упаковка 10 штук.", 110, "упаковка", 80, "in_stock", "both", [L(RND, "Ленинский район"), loc["Аксай"]], "active"),
        (s2, "Мёд подсолнечный", "Мёд", "Натуральный мёд с собственной пасеки, банка 1 кг.", 450, "упаковка", 40, "in_stock", "both", [loc["Новочеркасск"], loc["Аксай"], loc["Батайск"]], "active"),
        (s3, "Хлеб ржаной на закваске", "Хлеб и выпечка", "Печём каждое утро в дровяной печи, вес буханки 600 г.", 150, "шт", 20, "in_stock", "pickup", [L(KRD, "Центральный округ")], "active"),
        (s2, "Яблочный сок прямого отжима", "Напитки", "Сок без сахара и консервантов, бутыль 3 л.", 160, "л", 35, "in_stock", "pickup", [loc["Аксай"]], "active"),
        (s3, "Мука цельнозерновая", "Бакалея", "Мука из зерна собственного помола, мешок 5 кг.", 95, "кг", 100, "in_stock", "both", [L(KRD, "Западный округ")], "moderation"),
        (s1, "Творог зернистый", "Молочное", "Домашний творог из коровьего молока, 9% жирности.", 300, "кг", 15, "in_stock", "pickup", [L(RND, "Ленинский район")], "moderation"),
        (s1, "Кабачки молодые", "Овощи", "Небольшие кабачки для жарки и кабачковой икры.", 40, "кг", 120, "in_stock", "pickup", [L(RND, "Октябрьский район")], "awaiting_payment"),
        (s3, "Сало солёное", "Мясо", "Домашнее сало с мясной прослойкой.", 520, "кг", 10, "in_stock", "pickup", [L(KRD, "Западный округ")], "rejected"),
        (s2, "Черешня", "Ягоды", "Сладкая крупная черешня, сезон закончился.", 400, "кг", 0, "on_order", "pickup", [loc["Новочеркасск"]], "expired"),
    ]
    ad_ids = []
    for n, (seller, title, cname, descr, price, unit, stock, avail, meet, locs, status) in enumerate(ads, 1):
        approved = status in ("awaiting_payment", "active", "expired")
        created = t - timedelta(days=3, hours=n)
        activated = t - timedelta(hours=2 + n % 5) if status == "active" else (t - timedelta(days=2) if status == "expired" else None)
        expires = (activated + logic.AD_LIFETIME) if status == "active" else (activated + logic.AD_LIFETIME if activated else None)
        ad_id = conn.execute(
            "INSERT INTO ads(seller_id, category_id, title, description, price, unit, stock, availability, meeting, status, "
            "created_at, approved_at, activated_at, expires_at, moderator_id, reject_reason, was_approved, is_demo) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (seller, cat[cname], title, descr, price, unit, stock or None, avail, meet, status, fmt(created),
             fmt(t - timedelta(hours=3)) if status == "awaiting_payment" else (fmt(created + timedelta(hours=1)) if approved else None),
             fmt(activated) if activated else None, fmt(expires) if expires else None,
             admin if status in ("awaiting_payment", "active", "expired", "rejected") else None,
             "Нет чёткого фото товара" if status == "rejected" else None, 1 if approved else 0,
             2 if status == "expired" else 1)).lastrowid
        ad_ids.append(ad_id)
        for lid in locs:
            conn.execute("INSERT INTO ad_locations VALUES (?,?)", (ad_id, lid))
        for k in range(1 + n % 2):
            rel = f"uploads/demo/ad{ad_id}_{k + 1}.jpg"
            make_photo(os.path.join(BASE_DIR, "static", rel), title, cname, k)
            conn.execute("INSERT INTO ad_photos(ad_id, file_path, position) VALUES (?,?,?)", (ad_id, rel, k + 1))
        if approved and status != "awaiting_payment":                       # оплаченные размещения
            conn.execute("INSERT INTO payments(ad_id, amount, status, external_tx_id, purpose, created_at, paid_at) "
                         "VALUES (?,?,?,?,?,?,?)", (ad_id, 9, "paid", f"demo-tx-{ad_id}-0", logic.payment_purpose(ad_id),
                                                    fmt(activated), fmt(activated)))
    for k, ad_id in enumerate(ad_ids[:9] * 2):                              # история продлений за неделю
        day = t - timedelta(days=1 + k % 6, hours=k % 5)
        conn.execute("INSERT INTO payments(ad_id, amount, status, external_tx_id, purpose, created_at, paid_at) "
                     "VALUES (?,?,?,?,?,?,?)", (ad_id, 9, "paid", f"demo-tx-{ad_id}-h{k}", logic.payment_purpose(ad_id),
                                                fmt(day), fmt(day)))

    # --- резервы, чат, избранное, жалобы, уведомления, журнал
    tomato, honey = ad_ids[0], ad_ids[9]
    conn.execute("INSERT INTO reservations(ad_id, buyer_id, quantity, status, created_at, expires_at) VALUES (?,?,?,?,?,?)",
                 (tomato, b1, 5, "requested", fmt(t - timedelta(minutes=10)), fmt(t + timedelta(minutes=50))))
    conn.execute("INSERT INTO reservations(ad_id, buyer_id, quantity, status, created_at, confirmed_at, expires_at) "
                 "VALUES (?,?,?,?,?,?,?)", (honey, b2, 2, "confirmed", fmt(t - timedelta(minutes=40)),
                                            fmt(t - timedelta(minutes=30)), fmt(t + timedelta(hours=2, minutes=30))))
    chat = conn.execute("INSERT INTO chats(ad_id, buyer_id, seller_id, created_at) VALUES (?,?,?,?)",
                        (tomato, b1, s1, fmt(t - timedelta(hours=1)))).lastrowid
    for k, (sender, text) in enumerate([(b1, "Здравствуйте! Помидоры сегодняшние?"),
                                        (s1, "Добрый день! Да, собрали сегодня утром."),
                                        (b1, "Отлично. Могу забрать на рынке «Привоз» после 17:00?"),
                                        (s1, "Конечно, буду на месте до 19:00.")]):
        conn.execute("INSERT INTO messages(chat_id, sender_id, text, created_at, is_read) VALUES (?,?,?,?,?)",
                     (chat, sender, text, fmt(t - timedelta(minutes=55 - 10 * k)), 1 if k < 3 else 0))
    conn.execute("INSERT INTO favorites VALUES (?,?)", (b1, tomato))
    conn.execute("INSERT INTO favorites VALUES (?,?)", (b1, ad_ids[5]))
    conn.execute("INSERT INTO complaints(user_id, ad_id, kind, text, created_at) VALUES (?,?,?,?,?)",
                 (b1, ad_ids[5], "complaint", "Фото не похоже на то, что продают на самом деле.", fmt(t - timedelta(hours=5))))
    conn.execute("INSERT INTO complaints(user_id, kind, text, status, admin_reply, created_at, answered_at) VALUES (?,?,?,?,?,?,?)",
                 (s2, "help", "Как продлить объявление после истечения срока?", "answered",
                  "Откройте объявление в разделе «Мои объявления» и нажмите «Продлить».", fmt(t - timedelta(days=1)),
                  fmt(t - timedelta(hours=23))))
    for uid, text, link in [(s1, "Покупатель Анна хочет зарезервировать 5 кг «Помидоры «Бычье сердце»».", "/seller/reservations"),
                            (s1, "Новое сообщение в чате по объявлению №1.", f"/chats/{chat}"),
                            (s3, "Объявление «Сало солёное» отклонено: Нет чёткого фото товара.", f"/seller/ads/{ad_ids[15]}")]:
        conn.execute("INSERT INTO notifications(user_id, text, link, created_at) VALUES (?,?,?,?)", (uid, text, link, ts()))
    conn.execute("INSERT INTO moderation_log(moderator_id, action, ad_id, details, created_at) VALUES (?,?,?,?,?)",
                 (admin, "reject", ad_ids[15], "Нет чёткого фото товара", ts(-timedelta(days=1))))
    for aid in ad_ids[:4]:
        conn.execute("INSERT INTO moderation_log(moderator_id, action, ad_id, details, created_at) VALUES (?,?,?,?,?)",
                     (admin, "approve", aid, None, ts(-timedelta(days=2))))
    conn.execute("COMMIT")


def renew_demo_ads(conn):
    """Демо-объявления живут 24 часа; при запуске приложения продлеваем истёкшие, чтобы каталог не пустовал."""
    t = now()
    conn.execute("UPDATE ads SET status = 'active', activated_at = ?, expires_at = ?, expiry_notified = 0 "
                 "WHERE is_demo = 1 AND status = 'expired'", (fmt(t - timedelta(hours=2)), fmt(t + timedelta(hours=22))))
    conn.execute("UPDATE ads SET status = 'awaiting_payment', approved_at = ? "
                 "WHERE is_demo = 1 AND was_approved = 1 AND status IN ('awaiting_payment','deleted') "
                 "AND id NOT IN (SELECT ad_id FROM payments WHERE status = 'paid')", (fmt(t - timedelta(hours=3)),))
