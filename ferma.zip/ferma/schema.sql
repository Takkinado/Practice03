-- =====================================================================
--  «Ферма» — маркетплейс локальных продуктов. Структура БД (SQLite, 3НФ).
--  Время хранится текстом 'ГГГГ-ММ-ДД ЧЧ:ММ:СС', деньги — в рублях.
-- =====================================================================
PRAGMA foreign_keys = ON;

-- ---------- Пользователи ----------
-- roles — битовая маска: 1 = покупатель, 2 = продавец, 4 = администратор (роли совмещаются)
-- Телефон храним только в виде HMAC-хеша (для входа) и маски (для показа); открытый номер
-- (public_phone) заполняется ТОЛЬКО если пользователь сам разрешил показывать его другим.
CREATE TABLE IF NOT EXISTS users (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    name             TEXT    NOT NULL,
    phone_hash       TEXT    NOT NULL UNIQUE,
    phone_masked     TEXT    NOT NULL,
    public_phone     TEXT,
    password_hash    TEXT    NOT NULL,
    roles            INTEGER NOT NULL DEFAULT 1 CHECK (roles BETWEEN 1 AND 7),
    farm_name        TEXT,
    avatar_path      TEXT,
    phone_confirmed  INTEGER NOT NULL DEFAULT 0 CHECK (phone_confirmed IN (0,1)),
    blocked_until    TEXT,                       -- временная блокировка продавца
    blocked_forever  INTEGER NOT NULL DEFAULT 0 CHECK (blocked_forever IN (0,1)),
    created_at       TEXT    NOT NULL
);

-- ---------- SMS-коды подтверждения номера продавца ----------
CREATE TABLE IF NOT EXISTS sms_codes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code       TEXT    NOT NULL,
    created_at TEXT    NOT NULL,
    used       INTEGER NOT NULL DEFAULT 0 CHECK (used IN (0,1))
);

-- ---------- Справочник категорий ----------
CREATE TABLE IF NOT EXISTS categories (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL UNIQUE,
    sort_order INTEGER NOT NULL DEFAULT 100
);

-- ---------- Локации: город / район / населённый пункт ----------
-- parent_id: район -> город. population нужен, чтобы отличить крупный город (> 500 тыс.).
CREATE TABLE IF NOT EXISTS locations (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    kind       TEXT    NOT NULL CHECK (kind IN ('city','district','settlement')),
    name       TEXT    NOT NULL,
    lat        REAL    NOT NULL,
    lon        REAL    NOT NULL,
    parent_id  INTEGER REFERENCES locations(id) ON DELETE RESTRICT,
    population INTEGER,
    CHECK (kind <> 'district' OR parent_id IS NOT NULL)
);

-- ---------- Соседние населённые пункты (связь симметрична: храним обе стороны) ----------
CREATE TABLE IF NOT EXISTS location_neighbors (
    location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    neighbor_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    PRIMARY KEY (location_id, neighbor_id),
    CHECK (location_id <> neighbor_id)
);

-- ---------- Локации продавца (до 10) и покупателя (от 1 до 5) ----------
CREATE TABLE IF NOT EXISTS seller_locations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id)     ON DELETE CASCADE,
    location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
    note        TEXT,                                     -- «рынок «Привоз»»
    UNIQUE (user_id, location_id)
);
CREATE TABLE IF NOT EXISTS buyer_locations (
    user_id     INTEGER NOT NULL REFERENCES users(id)     ON DELETE CASCADE,
    location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
    PRIMARY KEY (user_id, location_id)
);

-- ---------- Объявления ----------
-- status: moderation -> awaiting_payment -> active -> expired; rejected; deleted
CREATE TABLE IF NOT EXISTS ads (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    seller_id       INTEGER NOT NULL REFERENCES users(id)      ON DELETE CASCADE,
    category_id     INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    title           TEXT    NOT NULL,
    description     TEXT    NOT NULL CHECK (length(description) <= 1500),
    price           REAL    NOT NULL CHECK (price > 0),
    unit            TEXT    NOT NULL CHECK (unit IN ('кг','л','шт','упаковка')),
    stock           REAL    CHECK (stock IS NULL OR stock >= 0),     -- сколько единиц есть (для резерва)
    availability    TEXT    NOT NULL CHECK (availability IN ('in_stock','on_order')),
    meeting         TEXT    NOT NULL CHECK (meeting IN ('pickup','delivery','both')),
    status          TEXT    NOT NULL DEFAULT 'moderation'
                    CHECK (status IN ('moderation','awaiting_payment','active','expired','rejected','deleted')),
    created_at      TEXT    NOT NULL,
    approved_at     TEXT,
    activated_at    TEXT,
    expires_at      TEXT,
    moderator_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    reject_reason   TEXT,
    was_approved    INTEGER NOT NULL DEFAULT 0 CHECK (was_approved IN (0,1)),  -- повторная модерация не нужна
    expiry_notified INTEGER NOT NULL DEFAULT 0 CHECK (expiry_notified IN (0,1)),
    is_demo         INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0,1,2))   -- 1 = демо (продлевается при запуске), 2 = демо-пример
);
CREATE INDEX IF NOT EXISTS ix_ads_status   ON ads(status);
CREATE INDEX IF NOT EXISTS ix_ads_seller   ON ads(seller_id);
CREATE INDEX IF NOT EXISTS ix_ads_category ON ads(category_id);
CREATE INDEX IF NOT EXISTS ix_ads_created  ON ads(created_at);

CREATE TABLE IF NOT EXISTS ad_photos (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    ad_id     INTEGER NOT NULL REFERENCES ads(id) ON DELETE CASCADE,
    file_path TEXT    NOT NULL,
    position  INTEGER NOT NULL DEFAULT 1
);

-- ---------- Где продаётся товар (многие ко многим: объявление <-> локация) ----------
CREATE TABLE IF NOT EXISTS ad_locations (
    ad_id       INTEGER NOT NULL REFERENCES ads(id)       ON DELETE CASCADE,
    location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
    PRIMARY KEY (ad_id, location_id)
);
CREATE INDEX IF NOT EXISTS ix_ad_locations_loc ON ad_locations(location_id);

-- ---------- Платежи за размещение (9 ₽ / 24 часа) ----------
CREATE TABLE IF NOT EXISTS payments (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    ad_id          INTEGER NOT NULL REFERENCES ads(id) ON DELETE CASCADE,
    amount         REAL    NOT NULL CHECK (amount >= 0),
    status         TEXT    NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','failed')),
    external_tx_id TEXT    UNIQUE,                      -- id транзакции у платёжного провайдера
    purpose        TEXT    NOT NULL,                    -- «Оплата объявления №123»
    qr_url         TEXT,                                -- ссылка на изображение QR-кода СБП
    created_at     TEXT    NOT NULL,
    paid_at        TEXT
);
CREATE INDEX IF NOT EXISTS ix_payments_ad     ON payments(ad_id);
CREATE INDEX IF NOT EXISTS ix_payments_status ON payments(status);

-- ---------- Резервы товара ----------
-- requested (ждёт продавца 1 ч) -> confirmed (действует 3 ч) -> expired;
-- rejected / auto_cancelled / cancelled
CREATE TABLE IF NOT EXISTS reservations (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    ad_id        INTEGER NOT NULL REFERENCES ads(id)   ON DELETE CASCADE,
    buyer_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    quantity     REAL    NOT NULL CHECK (quantity > 0),
    status       TEXT    NOT NULL DEFAULT 'requested'
                 CHECK (status IN ('requested','confirmed','rejected','auto_cancelled','cancelled','expired')),
    created_at   TEXT    NOT NULL,
    confirmed_at TEXT,
    expires_at   TEXT    NOT NULL                       -- срок ответа продавца или конец резерва
);
CREATE INDEX IF NOT EXISTS ix_reservations_ad    ON reservations(ad_id, status);
CREATE INDEX IF NOT EXISTS ix_reservations_buyer ON reservations(buyer_id);

-- ---------- Избранное ----------
CREATE TABLE IF NOT EXISTS favorites (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    ad_id   INTEGER NOT NULL REFERENCES ads(id)   ON DELETE CASCADE,
    PRIMARY KEY (user_id, ad_id)
);

-- ---------- Чат покупателя с продавцом (прокси-чат внутри сайта, номера не раскрываются) ----------
CREATE TABLE IF NOT EXISTS chats (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    ad_id      INTEGER NOT NULL REFERENCES ads(id)   ON DELETE CASCADE,
    buyer_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    seller_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT    NOT NULL,
    UNIQUE (ad_id, buyer_id)
);
CREATE TABLE IF NOT EXISTS messages (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id    INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    sender_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    text       TEXT    NOT NULL CHECK (length(text) BETWEEN 1 AND 2000),
    created_at TEXT    NOT NULL,
    is_read    INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0,1))
);
CREATE INDEX IF NOT EXISTS ix_messages_chat ON messages(chat_id);

-- ---------- Уведомления (аналог push-сообщений бота) ----------
CREATE TABLE IF NOT EXISTS notifications (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    text       TEXT    NOT NULL,
    link       TEXT,
    created_at TEXT    NOT NULL,
    is_read    INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0,1))
);
CREATE INDEX IF NOT EXISTS ix_notifications_user ON notifications(user_id, is_read);

-- ---------- Жалобы и обращения в поддержку ----------
CREATE TABLE IF NOT EXISTS complaints (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    ad_id       INTEGER REFERENCES ads(id) ON DELETE SET NULL,
    kind        TEXT    NOT NULL CHECK (kind IN ('complaint','help')),
    text        TEXT    NOT NULL,
    status      TEXT    NOT NULL DEFAULT 'new' CHECK (status IN ('new','answered')),
    admin_reply TEXT,
    created_at  TEXT    NOT NULL,
    answered_at TEXT
);

-- ---------- Журнал действий модераторов и рассылки ----------
CREATE TABLE IF NOT EXISTS moderation_log (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    moderator_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    action       TEXT    NOT NULL,
    ad_id        INTEGER REFERENCES ads(id)   ON DELETE SET NULL,
    user_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
    details      TEXT,
    created_at   TEXT    NOT NULL
);
CREATE TABLE IF NOT EXISTS broadcasts (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    text       TEXT    NOT NULL,
    sent_to    INTEGER NOT NULL,
    created_at TEXT    NOT NULL
);
