"""Бизнес-правила «Фермы»: роли, телефоны, локации, жизненный цикл объявлений, платежи, резервы."""
import hashlib
import hmac
import json
import os
import re
import time
from datetime import datetime, timedelta

from db import fmt, get_db, now, now_s, q_all, q_one, q_val

# ----------------------------------------------------------------------------
# Константы (значения из ТЗ)
# ----------------------------------------------------------------------------
ROLE_BUYER, ROLE_SELLER, ROLE_ADMIN = 1, 2, 4
AD_PRICE_RUB = 9                 # цена размещения на 24 часа
AD_LIFETIME = timedelta(hours=24)
MAX_OPEN_ADS = 100               # не более 100 «живых» объявлений у продавца
MAX_SELLER_LOCS, MAX_BUYER_LOCS = 10, 5
BIG_CITY_POPULATION = 500_000    # крупный город — нужен район
MAX_PHOTOS, MAX_PHOTOS_BYTES = 5, 10 * 1024 * 1024
RESERVE_ANSWER_TIME = timedelta(hours=1)    # продавец должен ответить за 1 час
RESERVE_HOLD_TIME = timedelta(hours=3)      # подтверждённый резерв действует 3 часа
PAYMENT_WAIT = timedelta(hours=1)           # ожидание подтверждения платежа
PAY_DEADLINE = timedelta(hours=24)          # после одобрения на оплату даётся 24 часа
PAID_MODE = os.environ.get("FERMA_PAID_MODE", "1") == "1"   # 0 = «первый год бесплатно»
DEMO_PAYMENTS = os.environ.get("FERMA_DEMO_PAYMENTS", "1") == "1"   # кнопка «имитировать оплату»
PHONE_PEPPER = os.environ.get("FERMA_PEPPER", "ferma-demo-pepper").encode()
WEBHOOK_SECRET = os.environ.get("PAYMENT_WEBHOOK_SECRET", "demo-webhook-secret").encode()
PAY_RECIPIENT = os.environ.get("FERMA_PAY_RECIPIENT", "ИП Фермеров И.И.")
PAY_ACCOUNT = os.environ.get("FERMA_PAY_ACCOUNT", "40802810000000000001")

UNITS = ["кг", "л", "шт", "упаковка"]
AD_STATUS = {"moderation": "На модерации", "awaiting_payment": "Ожидает оплаты", "active": "Активно",
             "expired": "Истекло", "rejected": "Отклонено", "deleted": "Удалено"}
RES_STATUS = {"requested": "Ожидает продавца", "confirmed": "Подтверждён", "rejected": "Отклонён продавцом",
              "auto_cancelled": "Отменён (продавец не ответил)", "cancelled": "Отменён покупателем",
              "expired": "Срок резерва истёк"}
AVAILABILITY = {"in_stock": "В наличии", "on_order": "Под заказ"}
MEETING = {"pickup": "Самовывоз", "delivery": "Доставка в пределах локации", "both": "Самовывоз и доставка"}
PRESET_REASONS = ["Нет чёткого фото товара", "Описание не соответствует товару", "Неверная категория",
                  "Недопустимый товар (алкоголь, табак, запрещённые вещества)", "Нецензурная лексика в тексте",
                  "Подозрение на мошенничество"]


# ----------------------------------------------------------------------------
# Телефон (в БД — только хеш и маска) и валидаторы
# ----------------------------------------------------------------------------
def normalize_phone(raw):
    """'+7 (900) 123-45-67' / '8900...' -> '79001234567'; None, если номер некорректен."""
    digits = re.sub(r"\D", "", raw or "")
    if len(digits) == 10:
        digits = "7" + digits
    if len(digits) == 11 and digits[0] == "8":
        digits = "7" + digits[1:]
    return digits if len(digits) == 11 and digits[0] == "7" else None


def phone_hash(phone):
    return hmac.new(PHONE_PEPPER, phone.encode(), hashlib.sha256).hexdigest()


def mask_phone(phone):
    return f"+7 ({phone[1:4]}) ***-**-{phone[9:]}"


def format_phone(phone):
    return f"+7 ({phone[1:4]}) {phone[4:7]}-{phone[7:9]}-{phone[9:]}" if phone and len(phone) == 11 else (phone or "")


def valid_name(name):
    return bool(name) and 2 <= len(name) <= 80


def check_password(pw):
    if len(pw or "") < 6:
        return "Пароль должен быть не короче 6 символов."
    return None


def has_role(user, flag):
    return bool(user and user["roles"] & flag)


def is_blocked(user):
    """Продавец заблокирован навсегда или до указанной даты."""
    if user["blocked_forever"]:
        return True
    return bool(user["blocked_until"] and user["blocked_until"] > now_s())


# ----------------------------------------------------------------------------
# Уведомления
# ----------------------------------------------------------------------------
def notify(conn, user_id, text, link=None):
    conn.execute("INSERT INTO notifications(user_id, text, link, created_at) VALUES (?,?,?,?)",
                 (user_id, text, link, now_s()))


# ----------------------------------------------------------------------------
# Локации
# ----------------------------------------------------------------------------
def is_big_city(loc):
    return loc["kind"] == "city" and (loc["population"] or 0) > BIG_CITY_POPULATION


def location_label(loc_id):
    # СВЯЗИ: locations.parent_id -> locations.id (район -> город): подпись «Город, Район».
    row = q_one("SELECT l.name AS name, p.name AS parent FROM locations AS l "
                "LEFT JOIN locations AS p ON p.id = l.parent_id WHERE l.id = ?", (loc_id,))
    return f"{row['parent']}, {row['name']}" if row and row["parent"] else (row["name"] if row else "")


def buyer_location_ids(user_id):
    """Локации покупателя + соседние НП для тех из них, что являются малыми населёнными пунктами."""
    # СВЯЗИ: buyer_locations N—1 locations (location_id): берём тип локации (settlement / district / city).
    base = q_all("SELECT l.id AS id, l.kind AS kind FROM buyer_locations AS bl "
                 "INNER JOIN locations AS l ON l.id = bl.location_id WHERE bl.user_id = ?", (user_id,))
    ids = {r["id"] for r in base}
    for r in base:
        if r["kind"] == "settlement":
            # СВЯЗИ: location_neighbors (location_id -> neighbor_id) — симметричная связь «соседние НП».
            ids.update(n["neighbor_id"] for n in q_all(
                "SELECT neighbor_id FROM location_neighbors WHERE location_id = ?", (r["id"],)))
    return ids


def ad_locations_text(ad_id):
    # СВЯЗИ: ads M—N locations через ad_locations; район подтягивает название города через parent_id.
    rows = q_all("SELECT l.name AS name, p.name AS parent FROM ad_locations AS al "
                 "INNER JOIN locations AS l ON l.id = al.location_id "
                 "LEFT JOIN locations AS p ON p.id = l.parent_id WHERE al.ad_id = ? ORDER BY l.name", (ad_id,))
    return [f"{r['parent']}, {r['name']}" if r["parent"] else r["name"] for r in rows]


# ----------------------------------------------------------------------------
# Автомодерация (опционально по ТЗ): мат, наркотики, алкоголь, табак
# ----------------------------------------------------------------------------
_BAD_PATTERNS = [
    (r"\bху[йеёи]\w*|\bпизд\w*|\b[её]б[аоуыи]\w*|\bбляд\w*|\bблят\w*|\bсук[аи]\b|\bмудак\w*|\bгандон\w*",
     "нецензурная лексика"),
    (r"\bнаркот\w*|\bгероин\w*|\bкокаин\w*|\bмарихуан\w*|\bгашиш\w*|\bспайс\w*|\bмефедрон\w*|\bамфетамин\w*",
     "упоминание наркотиков"),
    (r"\bводк\w*|\bконьяк\w*|\bвиски\b|\bсамогон\w*|\bпив[оаеуы]\b|\bвин[оаеуы]\b|\bспирт\w*|\bалкогол\w*"
     r"|\bтекил\w*|\bчач[аеиу]\b|\bнастойк\w*", "упоминание алкоголя"),
    (r"\bтабак\w*|\bсигарет\w*|\bсигар[ау]?\b|\bкальян\w*|\bвейп\w*", "упоминание табака"),
]


def premoderation_problem(*texts):
    """Текст причины автоотклонения или None, если запрещённых слов нет."""
    low = " ".join(t for t in texts if t).lower()
    for pattern, label in _BAD_PATTERNS:
        if re.search(pattern, low):
            return f"Автопроверка: в объявлении найдено — {label}. Исправьте текст и отправьте снова."
    return None


# ----------------------------------------------------------------------------
# Объявления: жизненный цикл
# ----------------------------------------------------------------------------
def open_ads_count(seller_id):
    return q_val("SELECT COUNT(*) FROM ads WHERE seller_id = ? AND status IN ('moderation','awaiting_payment','active')",
                 (seller_id,))


def reserved_qty(conn, ad_id):
    """Сколько единиц сейчас в подтверждённых резервах."""
    row = conn.execute("SELECT SUM(quantity) FROM reservations WHERE ad_id = ? AND status = 'confirmed'",
                       (ad_id,)).fetchone()
    return row[0] or 0


def available_qty(conn, ad):
    """Остаток для резерва (None — количество не ограничено)."""
    if ad["stock"] is None:
        return None
    return max(0, ad["stock"] - reserved_qty(conn, ad["id"]))


def activate_ad(conn, ad_id):
    """Оплата получена: объявление активно ещё 24 часа (продление — прибавляется к текущему сроку)."""
    ad = conn.execute("SELECT status, expires_at FROM ads WHERE id = ?", (ad_id,)).fetchone()
    t = now()
    if ad["status"] == "active" and ad["expires_at"] and ad["expires_at"] > fmt(t):
        new_exp = fmt(datetime.strptime(ad["expires_at"], "%Y-%m-%d %H:%M:%S") + AD_LIFETIME)
        conn.execute("UPDATE ads SET expires_at = ?, expiry_notified = 0 WHERE id = ?", (new_exp, ad_id))
    else:
        conn.execute("UPDATE ads SET status = 'active', activated_at = ?, expires_at = ?, expiry_notified = 0, "
                     "reject_reason = NULL WHERE id = ?", (fmt(t), fmt(t + AD_LIFETIME), ad_id))


def can_pay(ad):
    """Платить можно за одобренное объявление: ждёт оплаты, активное (продление) или истёкшее."""
    return ad["status"] in ("awaiting_payment", "active", "expired") and bool(ad["was_approved"])


# ----------------------------------------------------------------------------
# Платежи (СБП): QR-код, webhook с подписью
# ----------------------------------------------------------------------------
def payment_purpose(ad_id):
    return f"Оплата объявления №{ad_id}"


def sbp_payload(ad_id):
    """Строка для QR-кода (формат платёжных реквизитов ST00012: сумма в копейках, назначение с номером)."""
    return (f"ST00012|Name={PAY_RECIPIENT}|PersonalAcc={PAY_ACCOUNT}|Sum={AD_PRICE_RUB * 100}"
            f"|Purpose={payment_purpose(ad_id)}")


def make_qr_png(payload, path):
    """Рисует QR-код в PNG (матрицу даёт кодировщик reportlab, рисуем через Pillow)."""
    from PIL import Image
    from reportlab.graphics.barcode import qrencoder
    qr = qrencoder.QRCode(None, qrencoder.QRErrorCorrectLevel.M)
    qr.addData(payload)
    qr.make()
    n, scale, border = qr.getModuleCount(), 8, 4
    size = (n + 2 * border) * scale
    img = Image.new("1", (size, size), 1)
    px = img.load()
    for r in range(n):
        for c in range(n):
            if qr.isDark(r, c):
                for dy in range(scale):
                    for dx in range(scale):
                        px[(c + border) * scale + dx, (r + border) * scale + dy] = 0
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)


def sign_body(body: bytes) -> str:
    return hmac.new(WEBHOOK_SECRET, body, hashlib.sha256).hexdigest()


def process_payment_webhook(conn, body: bytes, signature: str):
    """Обработка webhook провайдера. Возвращает (http_status, dict)."""
    if not signature or not hmac.compare_digest(signature, sign_body(body)):
        return 403, {"ok": False, "error": "bad signature"}
    try:
        data = json.loads(body.decode("utf-8"))
        tx_id, purpose = str(data["tx_id"]), str(data["purpose"])
        amount, status = float(data["amount"]), data.get("status", "success")
    except (ValueError, KeyError, TypeError):
        return 400, {"ok": False, "error": "bad payload"}
    m = re.search(r"(?:№|No\.?\s*|N\s*)(\d+)", purpose)       # номер объявления берём из назначения
    if not m:
        return 422, {"ok": False, "error": "ad number not found in purpose"}
    ad_id = int(m.group(1))
    ad = conn.execute("SELECT * FROM ads WHERE id = ?", (ad_id,)).fetchone()
    if ad is None:
        return 404, {"ok": False, "error": "ad not found"}
    if conn.execute("SELECT 1 FROM payments WHERE external_tx_id = ?", (tx_id,)).fetchone():
        return 200, {"ok": True, "duplicate": True}               # повторная доставка webhook — идемпотентность

    pay = conn.execute("SELECT * FROM payments WHERE ad_id = ? AND status = 'pending' ORDER BY id DESC LIMIT 1",
                       (ad_id,)).fetchone()
    link = f"/seller/ads/{ad_id}"
    if status != "success" or amount < AD_PRICE_RUB or not can_pay(ad):
        if pay:
            conn.execute("UPDATE payments SET status = 'failed', external_tx_id = ? WHERE id = ?", (tx_id, pay["id"]))
        reason = "платёж не прошёл" if status != "success" else (
            "сумма меньше 9 ₽" if amount < AD_PRICE_RUB else "объявление нельзя оплатить в текущем статусе")
        notify(conn, ad["seller_id"], f"Оплата объявления №{ad_id} не принята: {reason}.", link)
        return 200, {"ok": False, "error": reason}
    with_pay = pay["id"] if pay else None
    if with_pay:
        conn.execute("UPDATE payments SET status = 'paid', external_tx_id = ?, paid_at = ?, amount = ? WHERE id = ?",
                     (tx_id, now_s(), amount, with_pay))
    else:       # провайдер сообщил о платеже, для которого сессию мы не создавали — фиксируем по номеру объявления
        conn.execute("INSERT INTO payments(ad_id, amount, status, external_tx_id, purpose, created_at, paid_at) "
                     "VALUES (?,?, 'paid', ?, ?, ?, ?)", (ad_id, amount, tx_id, purpose, now_s(), now_s()))
    activate_ad(conn, ad_id)
    until = conn.execute("SELECT expires_at FROM ads WHERE id = ?", (ad_id,)).fetchone()[0]
    notify(conn, ad["seller_id"], f"Оплата объявления №{ad_id} получена. Оно активно до {until[:16]}.", link)
    return 200, {"ok": True}


# ----------------------------------------------------------------------------
# Автоматические действия по таймерам (вызывается из before_request, не чаще раза в N секунд)
# ----------------------------------------------------------------------------
_last_refresh = 0.0


def refresh(conn, force=False):
    global _last_refresh
    if not force and time.time() - _last_refresh < 15:
        return
    _last_refresh = time.time()
    t = now()
    t_s = fmt(t)
    soon = fmt(t + timedelta(hours=1))

    # 1) за час до конца — уведомление продавцу и тем, у кого объявление в избранном
    # СВЯЗИ: ads 1—N favorites (ad_id): подписчики объявления получают то же уведомление.
    for ad in conn.execute("SELECT id, seller_id, title FROM ads WHERE status = 'active' AND expiry_notified = 0 "
                           "AND expires_at <= ? AND expires_at > ?", (soon, t_s)).fetchall():
        notify(conn, ad["seller_id"], f"Размещение «{ad['title']}» (№{ad['id']}) истекает меньше чем через час.",
               f"/seller/ads/{ad['id']}")
        for f in conn.execute("SELECT user_id FROM favorites WHERE ad_id = ?", (ad["id"],)).fetchall():
            notify(conn, f["user_id"], f"Товар из избранного скоро исчезнет: «{ad['title']}».", f"/ad/{ad['id']}")
        conn.execute("UPDATE ads SET expiry_notified = 1 WHERE id = ?", (ad["id"],))

    # 2) истёкшие объявления
    for ad in conn.execute("SELECT id, seller_id, title FROM ads WHERE status = 'active' AND expires_at <= ?",
                           (t_s,)).fetchall():
        conn.execute("UPDATE ads SET status = 'expired' WHERE id = ?", (ad["id"],))
        notify(conn, ad["seller_id"], f"Объявление «{ad['title']}» (№{ad['id']}) истекло. Его можно продлить.",
               f"/seller/ads/{ad['id']}")

    # 3) одобрено, но не оплачено в течение 24 часов — удаляется
    limit = fmt(t - PAY_DEADLINE)
    for ad in conn.execute("SELECT id, seller_id, title FROM ads WHERE status = 'awaiting_payment' "
                           "AND approved_at <= ?", (limit,)).fetchall():
        conn.execute("UPDATE ads SET status = 'deleted', reject_reason = 'Не оплачено в течение 24 часов' "
                     "WHERE id = ?", (ad["id"],))
        notify(conn, ad["seller_id"], f"Объявление «{ad['title']}» удалено: оплата не поступила за 24 часа.")

    # 4) платёжная сессия без подтверждения дольше часа — неуспешна (можно создать новую)
    # СВЯЗИ: payments N—1 ads (ad_id): чтобы уведомить владельца объявления.
    for p in conn.execute("SELECT p.id AS id, a.seller_id AS seller_id, a.id AS ad_id FROM payments AS p "
                          "INNER JOIN ads AS a ON a.id = p.ad_id WHERE p.status = 'pending' AND p.created_at <= ?",
                          (fmt(t - PAYMENT_WAIT),)).fetchall():
        conn.execute("UPDATE payments SET status = 'failed' WHERE id = ?", (p["id"],))
        notify(conn, p["seller_id"], f"Оплата объявления №{p['ad_id']} не подтверждена за час. Повторите попытку.",
               f"/seller/ads/{p['ad_id']}")

    # 5) резервы: продавец не ответил за час / срок резерва вышел
    # СВЯЗИ: reservations N—1 ads (ad_id): название товара для текста уведомления.
    for r in conn.execute("SELECT r.id AS id, r.buyer_id AS buyer_id, a.title AS title, a.id AS ad_id "
                          "FROM reservations AS r INNER JOIN ads AS a ON a.id = r.ad_id "
                          "WHERE r.status = 'requested' AND r.expires_at <= ?", (t_s,)).fetchall():
        conn.execute("UPDATE reservations SET status = 'auto_cancelled' WHERE id = ?", (r["id"],))
        notify(conn, r["buyer_id"], f"Резерв «{r['title']}» отменён: продавец не ответил за час.", f"/ad/{r['ad_id']}")
    conn.execute("UPDATE reservations SET status = 'expired' WHERE status = 'confirmed' AND expires_at <= ?", (t_s,))


# ----------------------------------------------------------------------------
# Вспомогательное для страниц
# ----------------------------------------------------------------------------
def decorate_ads(rows):
    """Добавляет к объявлениям первое фото, список локаций и остаток с учётом резервов."""
    out = []
    for r in rows:
        d = dict(r)
        d["photo"] = d.get("photo") or q_val(
            "SELECT file_path FROM ad_photos WHERE ad_id = ? ORDER BY position LIMIT 1", (d["id"],), None)
        d["locations"] = ad_locations_text(d["id"])
        d["reserved"] = reserved_qty(get_db(), d["id"])
        d["available"] = None if d["stock"] is None else max(0, d["stock"] - d["reserved"])
        out.append(d)
    return out


def paginate(total, page, per_page):
    pages = max(1, -(-total // per_page))
    page = min(max(page, 1), pages)
    return page, pages, (page - 1) * per_page
