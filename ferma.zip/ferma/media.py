"""Загрузка и проверка изображений (фото объявлений и аватары)."""
import io
import os
import secrets

from PIL import Image

import logic
from db import BASE_DIR

UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")


def read_photos(files):
    """Проверяет 1–5 фото: JPG/PNG, не больше 10 МБ суммарно. Возвращает ([(bytes, ext)], ошибка)."""
    files = [f for f in files if f and f.filename]
    if not 1 <= len(files) <= logic.MAX_PHOTOS:
        return None, f"Загрузите от 1 до {logic.MAX_PHOTOS} фотографий."
    items, total = [], 0
    for f in files:
        data = f.read()
        total += len(data)
        try:
            img = Image.open(io.BytesIO(data))
            img.verify()                                   # файл должен быть настоящей картинкой
            fmt = img.format
        except Exception:
            return None, f"Файл «{f.filename}» не является изображением."
        if fmt not in ("JPEG", "PNG"):
            return None, f"Файл «{f.filename}»: допустимы только JPG и PNG."
        items.append((data, "png" if fmt == "PNG" else "jpg"))
    if total > logic.MAX_PHOTOS_BYTES:
        return None, "Суммарный размер фото больше 10 МБ."
    return items, None


def save_photos(items, ad_id):
    """Сохраняет файлы на диск, возвращает относительные пути (для static/)."""
    folder = os.path.join(UPLOAD_DIR, "ads", str(ad_id))
    os.makedirs(folder, exist_ok=True)
    paths = []
    for n, (data, ext) in enumerate(items, 1):
        name = f"{n}_{secrets.token_hex(4)}.{ext}"
        with open(os.path.join(folder, name), "wb") as fh:
            fh.write(data)
        paths.append(f"uploads/ads/{ad_id}/{name}")
    return paths


def save_avatar(file, user_id):
    """Аватар: квадрат 256×256 JPEG. Возвращает (путь, ошибка)."""
    try:
        img = Image.open(io.BytesIO(file.read()))
        img.verify()
        file.seek(0)
        img = Image.open(io.BytesIO(file.read())).convert("RGB")
    except Exception:
        return None, "Файл аватара не является изображением."
    side = min(img.size)
    img = img.crop(((img.width - side) // 2, (img.height - side) // 2,
                    (img.width + side) // 2, (img.height + side) // 2)).resize((256, 256))
    os.makedirs(os.path.join(UPLOAD_DIR, "avatars"), exist_ok=True)
    rel = f"uploads/avatars/{user_id}.jpg"
    img.save(os.path.join(BASE_DIR, "static", rel), "JPEG", quality=88)
    return rel, None
